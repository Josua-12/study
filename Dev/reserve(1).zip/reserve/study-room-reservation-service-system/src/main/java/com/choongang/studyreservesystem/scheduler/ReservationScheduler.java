package com.choongang.studyreservesystem.scheduler;

import com.choongang.studyreservesystem.domain.Reservation;
import com.choongang.studyreservesystem.repository.ReservationRepository;
import lombok.RequiredArgsConstructor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class ReservationScheduler {

    private final ReservationRepository reservationRepository;

    // 5분마다 실행
    @Scheduled(cron = "0 0/5 * * * *")
    @Transactional
    public void checkAndCompleteReservations() {
        log.info("🔍 [Scheduler] 이용 완료 대상 예약을 검사합니다. 시간: {}", LocalDateTime.now());

        List<Reservation> endedReservations =
                reservationRepository.findAllByEndTimeBeforeAndStatus(
                        LocalDateTime.now(),
                        Reservation.ReservationStatus.CONFIRMED
                );

        if (endedReservations.isEmpty()) {
            log.info("[Scheduler] 완료 처리할 예약이 없습니다.");
            return;
        }

        for (Reservation res : endedReservations) {
            res.setStatus(Reservation.ReservationStatus.COMPLETED);
            reservationRepository.save(res);
            log.info("[Scheduler] 예약 ID {} 상태를 COMPLETED로 변경 완료.", res.getReservationId());
        }
    }
}