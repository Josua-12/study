package com.choongang.studyreservesystem.dto.comment;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Getter
@AllArgsConstructor
public class CommentSaveDto {

    @NotBlank(message = "내용은 반드시 입력하셔야합니다.")
    @Size(max = 1000, message = "최대 1000자 입니다.")
    private String comment;

    @NotNull
    private Long boardId;

}
