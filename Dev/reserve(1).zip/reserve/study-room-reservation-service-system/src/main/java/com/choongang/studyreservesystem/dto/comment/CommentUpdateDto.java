package com.choongang.studyreservesystem.dto.comment;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CommentUpdateDto {

    @NotBlank(message = "내용은 반드시 입력하셔야합니다.")
    @Size(max = 1000, message = "최대 1000자 입니다.")
    private String comment;
}
