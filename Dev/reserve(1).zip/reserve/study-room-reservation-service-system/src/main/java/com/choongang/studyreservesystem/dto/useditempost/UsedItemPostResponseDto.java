package com.choongang.studyreservesystem.dto.useditempost;

import com.choongang.studyreservesystem.domain.UsedItemPost;
import com.choongang.studyreservesystem.domain.enums.UsedItemStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UsedItemPostResponseDto {
    private Long itemId;
    private String title;
    private String content;
    private Integer price;
    private UsedItemStatus status;
    private String location;
    private Long viewCount;
    private Long likeCount;
    private Long authorId;
    private String authorUsername;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public static UsedItemPostResponseDto from(UsedItemPost usedItemPost) {
        return UsedItemPostResponseDto.builder()
                .itemId(usedItemPost.getId())
                .title(usedItemPost.getTitle())
                .content(usedItemPost.getContent())
                .price(usedItemPost.getPrice())
                .status(usedItemPost.getStatus())
                .location(usedItemPost.getLocation())
                .viewCount(usedItemPost.getViewCount())
                .likeCount(usedItemPost.getLikeCount())
                .authorId(usedItemPost.getAuthor().getId())
                .authorUsername(usedItemPost.getAuthor().getUsername())
                .createdAt(usedItemPost.getCreatedAt())
                .updatedAt(usedItemPost.getUpdatedAt())
                .build();
    }
}
