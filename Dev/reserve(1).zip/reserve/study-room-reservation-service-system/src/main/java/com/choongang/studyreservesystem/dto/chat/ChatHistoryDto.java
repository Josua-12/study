package com.choongang.studyreservesystem.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatHistoryDto {

    private Long chatRoomId;
    private Long senderId;
    private String message;
    private String senderName;
    private LocalDateTime createTime;
}
