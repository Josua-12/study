package com.choongang.studyreservesystem.service.Impl;

import com.choongang.studyreservesystem.domain.Board;
import com.choongang.studyreservesystem.domain.Comment;
import com.choongang.studyreservesystem.dto.comment.CommentResponseDto;
import com.choongang.studyreservesystem.dto.comment.CommentSaveDto;
import com.choongang.studyreservesystem.dto.comment.CommentUpdateDto;
import com.choongang.studyreservesystem.exception.BoardNotFoundException;
import com.choongang.studyreservesystem.exception.CommentNotFoundException;
import com.choongang.studyreservesystem.repository.BoardRepository;
import com.choongang.studyreservesystem.repository.CommentRepository;
import com.choongang.studyreservesystem.service.CommentService;
import lombok.RequiredArgsConstructor;
import com.choongang.studyreservesystem.domain.User;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
@Transactional(readOnly = true)
@Service
public class CommentServiceImpl implements CommentService {

    private final CommentRepository commentRepository;
    private final BoardRepository boardRepository;

    @Transactional
    @Override
    public CommentResponseDto saveComment(CommentSaveDto commentSaveDto, User user) {
        // dto 보드 아이디로 보드 엔티티 조회
        Board board = boardRepository.findById(commentSaveDto.getBoardId())
                .orElseThrow(() -> new BoardNotFoundException("해당 ID의 게시글을 찾을 수 없습니다: " + commentSaveDto.getBoardId()));
        //저장할 Comment 엔티티 생성
        Comment newComment = Comment.builder()
                .comment(commentSaveDto.getComment())
                .board(board)
                .user(user)
                .build();
        //저장할 Comment 엔티티로 db에 저장하고 savedComment객체로 받음
        Comment savedComment = commentRepository.save(newComment);

        //받은 객체를 DTO로 변환하여 반환
        return CommentResponseDto.from(savedComment);
    }

    @Transactional
    @Override
    public CommentResponseDto updateComment(Long commentId, CommentUpdateDto commentUpdateDto, User user) {
        //수정할 댓글이 있는지 확인
        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new CommentNotFoundException(commentId + "인 댓글을 찾을 수 없습니다."));
        //수정을 요청한 사용자가 작성자인지 확인
        if (!comment.getUser().getId().equals(user.getId())) {
            throw new AccessDeniedException("해당 댓글을 수정할 권한이 없습니다.");
        }
        //코멘트 클래스의 내부메서드를 통해 내용 수정
        comment.updateComment(commentUpdateDto.getComment());
        //수정한 코멘트를 Dto로 변환하여 반환
        return CommentResponseDto.from(comment);
    }

    @Override
    public List<CommentResponseDto> findByBoardPostId(Long postId) {

        List<Comment> comments = commentRepository.findByBoardPostId(postId);
        return comments.stream()
                .map(CommentResponseDto::from)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public void deleteComment(Long commentId, User currentUser) {
        commentRepository.deleteById(commentId);
    }


}
