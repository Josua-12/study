package com.choongang.studyreservesystem.repository.jpa;

import com.choongang.studyreservesystem.dto.RoomSearchConditionDto;
import com.choongang.studyreservesystem.dto.RoomSummaryProjection;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


public interface RoomRepositoryCustom {
    Page<RoomSummaryProjection> search(RoomSearchConditionDto cond, Pageable pageable);
    Page<RoomSummaryProjection> findNear(double lat, double lng, int radius, Pageable pageable);
}
