package com.choongang.studyreservesystem.repository;

import com.choongang.studyreservesystem.domain.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {

    List<Review> findAllByRoom_RoomId(Long roomId);

    long countByRoom_RoomId(Long roomId);

    List<Review> findAllByRoom_RoomIdOrderByIdDesc(Long roomId);

    boolean existsByRoom_RoomIdAndUser_Username(Long roomId, String username);
}