package com.choongang.studyreservesystem.mapper;

import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.domain.chat.Chat;
import com.choongang.studyreservesystem.domain.chat.ChatRoom;
import com.choongang.studyreservesystem.dto.UserResponseDto;
import com.choongang.studyreservesystem.dto.chat.ChatDto;
import com.choongang.studyreservesystem.dto.chat.ChatHistoryDto;
import com.choongang.studyreservesystem.dto.chat.ChatRoomResponseDto;
import com.choongang.studyreservesystem.dto.chat.ChatUserResponseDto;
import org.springframework.stereotype.Component;

@Component
public class ChatDataMapper {

    public ChatHistoryDto chatToChatHistoryDto(Long chatRoomId, Chat chat) {
        return new ChatHistoryDto(chatRoomId, chat.getUserId(), chat.getMessage(),
                chat.getSenderName(), chat.getCreateTime());
    }

    public UserResponseDto userToUserResponseDto(User user) {
        return new UserResponseDto(user.getUsername(), user.getEmail());
    }

    public ChatUserResponseDto userToChatUserResponseDto(User user) {
        ChatUserResponseDto dto = new ChatUserResponseDto();
        dto.setUsername(user.getUsername());
        dto.setUserId(user.getId());
        return dto;
    }

    public ChatRoomResponseDto chatRoomToChatRoomResponseDto(ChatRoom chatRoom, User user) {
        ChatRoomResponseDto dto = new ChatRoomResponseDto();
        dto.setLastChatTime(null);
        dto.setLastMessage(null);
        chatRoom.getChats().stream()
                .max((c1, c2) -> c1.getCreateTime().compareTo(c2.getCreateTime()))
                .ifPresent(chat -> {
                    dto.setLastChatTime(chat.getCreateTime());
                    dto.setLastMessage(chat.getMessage());
                });
        dto.setChatRoomId(chatRoom.getChatRoomId());
        dto.setRoomName(chatRoom.getRoomName());
        dto.setMasterName(chatRoom.getMasterName());
        dto.setParticipantsCount((long) chatRoom.getParticipants().size()); // +1 for master
        return dto;
    }

    public ChatRoomResponseDto toChatRoomResponseDto(ChatRoom chatRoom) {
        ChatRoomResponseDto dto = new ChatRoomResponseDto();
        dto.setChatRoomId(chatRoom.getChatRoomId());
        dto.setRoomName(chatRoom.getRoomName());
        dto.setMasterName(chatRoom.getMasterName());
        dto.setParticipantsCount((long) chatRoom.getParticipants().size() + 1); // +1 for master
        dto.setLastChatTime(null);
        dto.setLastMessage(null);
        chatRoom.getChats().stream()
                .max((c1, c2) -> c1.getCreateTime().compareTo(c2.getCreateTime()))
                .ifPresent(chat -> {
                    dto.setLastChatTime(chat.getCreateTime());
                    dto.setLastMessage(chat.getMessage());
                });
        return dto;
    }
}
