package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.dto.useditempost.UpdateUsedItemPostDto;
import com.choongang.studyreservesystem.dto.useditempost.UsedItemPostResponseDto;
import com.choongang.studyreservesystem.security.CustomUserDetails;
import com.choongang.studyreservesystem.service.UsedItemPostService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Slf4j
@RequiredArgsConstructor
@RequestMapping("/useditempost")
@Controller
public class UsedItemPostController {

    private final UsedItemPostService usedItemPostService;

    @GetMapping("/{id}/edit")
    public String editForm(
            @PathVariable Long id,
            @AuthenticationPrincipal CustomUserDetails userDetails,
            Model model,
            RedirectAttributes redirectAttributes
    ) {
        try {
            // 현재 로그인한 사용아 PK
            Long userId = userDetails.getId();

            //수정할 게시글 조회 (검증 포함)
            UsedItemPostResponseDto post = usedItemPostService.getPostForEdit(id, userId);

            UpdateUsedItemPostDto updateDto = UpdateUsedItemPostDto.builder()
                    .title(post.getTitle())
                    .content(post.getContent())
                    .price(post.getPrice())
                    .location(post.getLocation())
                    .build();

            model.addAttribute("post", updateDto);
            model.addAttribute("postId", id);

            // 수정 시 보여줄 폼에 현재 상태를 수정자가 알 수 있게
            model.addAttribute("currentStatus", post.getStatus());

            return "useditempost/updateForm";

        } catch (EntityNotFoundException e) {
            log.error("editForm 메서드: 존재하지 않는 게시글 ID : {}", id);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/useditempost";
        } catch (AccessDeniedException e) {
            log.error("수정 폼 요청: 권한 없음 (userId: {}, postId: {})", userDetails.getId(), id);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/useditempost";
        }
    }

    @PostMapping("/{id}")
    public String updatePost(
            @PathVariable Long id,
            @Valid @ModelAttribute("post") UpdateUsedItemPostDto updateDto,
            BindingResult bindingResult,
            @AuthenticationPrincipal CustomUserDetails userDetails,
            Model model,
            RedirectAttributes redirectAttributes
    ) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("postId", id); // 폼 action URL을 위해 ID 다시 추가
            return "useditempost/updateForm";
        }

        log.info("게시글 수정 시작. postId: {}", id);

        try {
            Long authorId = userDetails.getId();

            usedItemPostService.updatePost(id, updateDto, authorId);

            redirectAttributes.addFlashAttribute("success", "게시글이 수정되었습니다.");
            log.info("게시글 수정이 완료되었습니다. postId: {}", id);

            return "redirect:/useditempost/" + id;

        } catch (EntityNotFoundException e) {
            log.error("게시글 수정 실패 : 존재하지 않는 리소스 (postId: {}, userId: {})", id, userDetails.getId());
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/useditempost";

        } catch (AccessDeniedException e) {
            log.error("게시글 수정 실패: 권한 없음 (userId: {}, postId: {})", userDetails.getId(), id);
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/useditempost/" + id;
        }
    }
}
