package com.choongang.studyreservesystem.service.Impl;

import com.choongang.studyreservesystem.domain.*;
import com.choongang.studyreservesystem.dto.review.ReviewResponseDTO;
import com.choongang.studyreservesystem.dto.review.ReviewSaveDto;
import com.choongang.studyreservesystem.dto.review.ReviewUpdateDto;
import com.choongang.studyreservesystem.repository.ReportRepository;
import com.choongang.studyreservesystem.repository.ReviewLikeRepository;
import com.choongang.studyreservesystem.repository.ReviewRepository;
import com.choongang.studyreservesystem.repository.UserRepository;
import com.choongang.studyreservesystem.repository.jpa.RoomRepository;
import com.choongang.studyreservesystem.service.ReviewService;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.transaction.annotation.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ReviewServiceImpl implements ReviewService {

    private final ReviewLikeRepository  reviewLikeRepository;
    private final ReviewRepository reviewRepository;
    private final UserRepository userRepository;
    private final RoomRepository roomRepository;
    private final ReportRepository reportRepository;

    @Transactional
    @Override
    public ReviewSaveDto saveReview(ReviewSaveDto reviewSaveDto, User user) {

        Room room = roomRepository.findById(reviewSaveDto.getRoomId())
                .orElseThrow(() -> new EntityNotFoundException("해당 ID의 룸을 찾을 수 없습니다: " + reviewSaveDto.getRoomId()));

        Review review = Review.builder()
                .content(reviewSaveDto.getContent())
                .room(room)
                .user(user)
                .rating(reviewSaveDto.getRating())
                .build();
        Review savedReview = reviewRepository.save(review);
        return ReviewSaveDto.from(savedReview);
    }

    @Transactional
    @Override
    public ReviewResponseDTO updateReview(Long reviewId, ReviewUpdateDto reviewUpdateDto, User user) {
        //수정할 리뷰가 있는지 확인
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new EntityNotFoundException("해당 ID의 리뷰를 찾을 수 없습니다: " + reviewId));
        //수정을 요청한 사용자가 작성자인지 확인

        if (!(review.getUser().getId().equals(user.getId()) || user.getRole().equals("ROLE_ADMIN"))) {
            throw new IllegalArgumentException("해당 댓글을 수정할 권한이 없습니다.");
        }


        review.update(reviewUpdateDto.getContent(), reviewUpdateDto.getRating(), user.getId());

        return ReviewResponseDTO.from(review);
    }

    @Transactional
    @Override
    public void deleteReview(Long reviewId, User user) {
        //삭제할 리뷰 찾기
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new EntityNotFoundException("해당 ID의 리뷰를 찾을 수 없습니다: " + reviewId));

        System.out.println("===== [리뷰 삭제 권한 확인] =====");
        System.out.println("삭제 시도자 (로그인 유저) ID: " + user.getId());
        System.out.println("리뷰 원작성자 ID: " + review.getUser().getId());
        System.out.println("두 ID 일치 여부: " + review.getUser().getId().equals(user.getId()));
        System.out.println("===============================");

        //권한 확인
        if (!review.getUser().getId().equals(user.getId()) && !user.getRole().equals("ADMIN")) {
            throw new IllegalArgumentException("해당 댓글을 삭제할 권한이 없습니다.");
        }

        //삭제
        reviewRepository.delete(review);
    }

    @Override
    public List<ReviewResponseDTO> getReviewByRoomId(Long roomId) {
        List<Review> reviews = reviewRepository.findAllByRoom_RoomIdOrderByIdDesc(roomId);
        return reviews.stream()
                .map(review->{
                    return ReviewResponseDTO.from(review);
                })
                .collect(Collectors.toList());
    }

    @Override
    public boolean hasUserLiked(Long reviewId, Long userId) {

        return reviewLikeRepository.findByReviewIdAndUserId(reviewId, userId).isPresent();
    }

    @Override
    @Transactional
    public void toggleLike(Long reviewId, Long userId) {

        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new EntityNotFoundException("해당 ID의 리뷰를 찾을 수 없습니다: " + reviewId));

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("해당 ID의 사용자를 찾을 수 없습니다: " + userId));


        boolean isLiked = this.hasUserLiked(reviewId, userId);

        if (isLiked) {
            reviewLikeRepository.deleteByReviewIdAndUserId(reviewId, userId);
            review.decrementLikeCount();

        } else {
            ReviewLike reviewLike = ReviewLike.builder()
                    .review(review)
                    .user(user)
                    .build();
            reviewLikeRepository.save(reviewLike);
            review.incrementLikeCount();
        }
    }

    @Override
    public boolean hasUserAlreadyReviewed(Long roomId, String username) {
        return reviewRepository.existsByRoom_RoomIdAndUser_Username(roomId, username);
    }

    @Override
    @Transactional(readOnly = true)
    public ReviewResponseDTO getReviewById(Long reviewId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new EntityNotFoundException("리뷰를 찾을 수 없습니다."));

        return ReviewResponseDTO.from(review);
    }

    public void reportReview(Long reviewId, String reason, User reporter) {

        Review targetReview = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new IllegalArgumentException("신고 대상 리뷰를 찾을수 없습니다."));

        Report report = Report.builder()
                .targetReview(targetReview)
                .reporterUser(reporter)
                .reason(reason)
                .reportedAt(LocalDateTime.now())
                .status(Report.ReportStatus.PENDING)
                .build();

        reportRepository.save(report);
    }
}
