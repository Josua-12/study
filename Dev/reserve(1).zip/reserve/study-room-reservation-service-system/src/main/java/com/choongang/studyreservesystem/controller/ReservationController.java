package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.dto.ReservationRequestDto;
import com.choongang.studyreservesystem.dto.ReservationResponseDto;
import com.choongang.studyreservesystem.service.ReservationService;
import com.choongang.studyreservesystem.service.UserService;
import com.choongang.studyreservesystem.service.jpa.RoomService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Controller
@RequiredArgsConstructor
@RequestMapping("/reservation")
public class ReservationController {
    private final ReservationService reservationService;
    private final RoomService roomService;
    private final UserService userService;

    @PostMapping("/create")
    @ResponseBody
    public ResponseEntity<?> createReservation(
            @Valid @RequestBody ReservationRequestDto requestDto,
            BindingResult bindingResult,
            @AuthenticationPrincipal UserDetails userDetails) {
        
        if (bindingResult.hasErrors()) {
            String errorMessage = bindingResult.getAllErrors().stream()
                    .map(DefaultMessageSourceResolvable::getDefaultMessage)
                    .findFirst()
                    .orElse("입력값이 올바르지 않습니다");
            return ResponseEntity.badRequest().body(errorMessage);
        }
        
        try {
            ReservationResponseDto response = reservationService.createReservation(
                    requestDto, userDetails.getUsername());
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/my/active")
    @ResponseBody
    public ResponseEntity<?> myActive(
            @RequestParam Long roomId,
            @AuthenticationPrincipal UserDetails user) {
        return reservationService.findActiveReservation(roomId, user.getUsername())
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.noContent().build());
    }

    @PostMapping("/cancel")
    @ResponseBody
    @Transactional
    public ResponseEntity<?> cancel(
            @RequestParam Long reservationId,
            @AuthenticationPrincipal UserDetails user) {
        try {
            return ResponseEntity.ok(
                    reservationService.cancelReservation(reservationId, user.getUsername()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/complete")
    public String reservationComplete(
            @RequestParam Long reservationId,
            Model model,
            @AuthenticationPrincipal UserDetails user) {
        ReservationResponseDto dto = reservationService.getReservation(reservationId, user.getUsername());
        boolean cancellable = "CONFIRMED".equals(dto.getStatus()) && dto.getStartTime().isAfter(LocalDateTime.now());
        model.addAttribute("reservation", dto);
        model.addAttribute("cancellable", cancellable);
        return "reservation/reservationComplete";
    }

    @GetMapping("/{id}")
    @ResponseBody
    public ResponseEntity<?> getReservation(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetails user) {
        return ResponseEntity.ok(reservationService.getReservation(id, user.getUsername()));
    }

    @GetMapping("/my")
    @ResponseBody
    public List<ReservationResponseDto> myReservations(
            @AuthenticationPrincipal UserDetails user) {
        return reservationService.findMyReservations(user.getUsername());
    }

    @GetMapping("/my-list")
    public String myReservationPage(Model model , @AuthenticationPrincipal UserDetails user){
        if(user==null){
            return "redirect:/login";
        }
        model.addAttribute("username",user.getUsername());

        return "reservation/myReservations";
    }
}
