package com.choongang.studyreservesystem.dto;

import lombok.Builder;
import lombok.Value;

import java.time.LocalTime;

@Value
@Builder
public class RoomSummaryDto {
    Long roomId;
    String roomName;
    String shortAddress;
    String content;
    Double latitude;
    Double longitude;
    Integer price;
    String roomType;
    String facilities;
    String contactInfo;
    String reservePolicy;
    Integer minCapacity;
    Integer maxCapacity;
    LocalTime openTime;
    LocalTime closeTime;
    Boolean isOpen24Hours;
    String internalPolicy;
    String thumbnailUrl;
    Integer distanceMeters;
    Boolean highlight;
}
