package com.choongang.studyreservesystem.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class InviteChatRoomDto {

    private Long roomId;
    private Long masterId;
    private Long inviteeId;
}
