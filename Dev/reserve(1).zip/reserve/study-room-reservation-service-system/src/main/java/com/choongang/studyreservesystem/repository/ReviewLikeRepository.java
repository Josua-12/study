package com.choongang.studyreservesystem.repository;

import com.choongang.studyreservesystem.domain.ReviewLike;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;

import java.util.Optional;

public interface ReviewLikeRepository extends JpaRepository<ReviewLike,Long> {
    Optional<ReviewLike> findByReviewIdAndUserId(Long reviewId,Long userId);

    @Modifying
    @Transactional
    void deleteByReviewIdAndUserId(Long reviewId, Long userId);
}
