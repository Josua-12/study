package com.choongang.studyreservesystem.domain;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ReviewStatus {
    ACTIVE("게시됨"),
    EDITED("수정됨"),
    HIDDEN("숨김"),
    DELETED("삭제됨");

    private final String label;

    @Override public String toString() { return label; }

    /** 전이 가능 **/
    public boolean canTransitTo(ReviewStatus target) {
        return switch (this) {
            case ACTIVE -> (target == EDITED || target == HIDDEN || target == DELETED);
            case EDITED -> (target == EDITED || target == HIDDEN || target == DELETED);
            case HIDDEN -> (target == ACTIVE || target == EDITED || target == DELETED);
            case DELETED -> false; // 삭제 후 종결
        };
    }
}
