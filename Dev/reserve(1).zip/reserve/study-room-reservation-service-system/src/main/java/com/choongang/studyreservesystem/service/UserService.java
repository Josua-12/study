package com.choongang.studyreservesystem.service;

import com.choongang.studyreservesystem.dto.UserFindUsernameDto;
import com.choongang.studyreservesystem.dto.UserPasswordChangeDto;
import com.choongang.studyreservesystem.dto.UserRegisterDto;
import com.choongang.studyreservesystem.dto.UserResponseDto;
import com.choongang.studyreservesystem.exception.UserDuplicationException;

import java.util.List;

public interface UserService {

    List<UserResponseDto> findAll();

    UserResponseDto findById(Long id);

    boolean existsByUsername(String username);

    void register(UserRegisterDto dto) throws UserDuplicationException;

    List<UserFindUsernameDto> findUserNameFromNameAndEmail(String name, String email);

    boolean matchUsernameAndEmail(UserPasswordChangeDto dto);

    void passwordChange(UserPasswordChangeDto dto);
}
