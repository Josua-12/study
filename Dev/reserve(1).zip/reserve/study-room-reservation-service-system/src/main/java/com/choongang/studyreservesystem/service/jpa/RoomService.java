package com.choongang.studyreservesystem.service.jpa;

import com.choongang.studyreservesystem.dto.RoomSearchConditionDto;
import com.choongang.studyreservesystem.dto.RoomSummaryDto;

import java.util.List;

public interface RoomService {
    List<RoomSummaryDto> findAllRooms(RoomSearchConditionDto cond);
    RoomSummaryDto findRoom(Long roomId);
    List<RoomSummaryDto> findRoomByLatitudeAndLongitude(Double latitude, Double longitude, Integer radius);
}
