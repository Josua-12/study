package com.choongang.studyreservesystem.dto;

public interface RoomSummaryProjection {
    Long getRoomId();
    String getRoomName();
    String getShortAddress();
    String getContent();

    Double getLatitude();
    Double getLongitude();
    Integer getPrice();
    String getRoomType();
    Integer getDistanceMeters();
}
