package com.choongang.studyreservesystem.dto.review;

import jakarta.validation.constraints.*;
import lombok.*;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReviewUpdateDto {

//    @NotNull
//    Long reviewId;
//
//    @NotNull
//    Long editorId;

    @NotBlank(message = "리뷰 내용은 필수 입니다.")
    @Size(max = 1000,message = "리뷰 내용은 1000자를 초과할수 없습니다.")
    private String content;

    @Min(value =1, message = "별점은 1점 이상이여야합니다,")
    @Max(value = 5,message = "별점은 5점을 초과할수 없습니다.")
    private Integer rating;

}