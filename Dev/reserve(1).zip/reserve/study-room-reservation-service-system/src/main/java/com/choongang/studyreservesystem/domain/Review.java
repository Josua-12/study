package com.choongang.studyreservesystem.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@SQLDelete(sql = "UPDATE review SET deleted = true WHERE id = ?")
@SQLRestriction("deleted = false")
public class Review extends BaseEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @Column(length = 1000, nullable = false)
    private String content;

    //1~10점 (클라이언트에게 표시할 때는 별 5개로 예상)
    private Integer rating;

    @Builder.Default
    private Long reportCount = 0L;

    @Builder.Default
    private Long likeCount = 0L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "users_id", nullable = false)
    private User user;
    @Builder.Default
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ReviewStatus status = ReviewStatus.ACTIVE;

    @Builder.Default
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Visibility visibility = Visibility.PUBLIC;

    @ManyToOne
    @JoinColumn(name = "reservation_id", nullable = true)
    private Reservation reservation;

    public void update(String newContent, Integer newRating, Long editorId) {
        setContent(newContent);
        setRating(newRating);
        this.changeStatus(ReviewStatus.EDITED); // 상태 갱신
    }

    public void changeStatus(ReviewStatus target) {
        if (!this.status.canTransitTo(target)) {
            throw new IllegalStateException("Illegal status transition: " + this.status + " -> " + target);
        }
        this.status = target;
    }

    public void hideByReport() {
        this.visibility = Visibility.HIDDEN_BY_REPORT;
        this.status = ReviewStatus.HIDDEN;
    }

    public void softDelete() {
        this.visibility = Visibility.ADMIN_ONLY;
        this.status = ReviewStatus.DELETED;
    }

    public void restore() {
        this.visibility = Visibility.PUBLIC;
        this.status = ReviewStatus.ACTIVE;
    }

    public void incrementLikeCount() {
        this.likeCount = (this.likeCount == null ? 1L : this.likeCount + 1);
    }

    public void decrementLikeCount() {
        this.likeCount = (this.likeCount == null || this.likeCount <= 0) ? 0L : this.likeCount - 1;
    }


}
