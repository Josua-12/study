package com.choongang.studyreservesystem.repository.impl;

import com.choongang.studyreservesystem.domain.chat.Chat;
import com.choongang.studyreservesystem.domain.chat.ChatRoom;
import com.choongang.studyreservesystem.repository.ChatRepository;
import com.choongang.studyreservesystem.repository.jpa.ChatJpaRepository;
import com.choongang.studyreservesystem.repository.jpa.ChatRomeJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ChatRepositoryImpl implements ChatRepository {

    private final ChatJpaRepository chatJpaRepository;
    private final ChatRomeJpaRepository chatRomeJpaRepository;

    @Autowired
    public ChatRepositoryImpl(ChatJpaRepository chatJpaRepository,
                              ChatRomeJpaRepository chatRomeJpaRepository) {
        this.chatJpaRepository = chatJpaRepository;
        this.chatRomeJpaRepository = chatRomeJpaRepository;
    }

    @Override
    public Chat saveChat(Chat chat) {
        return chatJpaRepository.save(chat);
    }

    @Override
    public ChatRoom saveChatRoom(ChatRoom chatRoom) {
        return chatRomeJpaRepository.save(chatRoom);
    }

    @Override
    public Optional<ChatRoom> findChatRoomById(Long chatRoomId) {
        return chatRomeJpaRepository.findById(chatRoomId);
    }

    @Override
    public Optional<ChatRoom> findChatRoomByMasterIdAndRoomName(Long masterId, String roomName) {
        return chatRomeJpaRepository.findChatRoomByMasterIdAndRoomName(masterId, roomName);
    }

    @Override
    public List<ChatRoom> findChatRoomsByUserId(Long userId) {
        return chatRomeJpaRepository.findChatRoomsByOverlappingUsers(List.of(userId));
    }

    @Override
    public void removeChatRoom(ChatRoom chatRoom) {
        chatRomeJpaRepository.delete(chatRoom);
    }
}
