package com.choongang.studyreservesystem.config;

import com.choongang.studyreservesystem.domain.Room;
import com.choongang.studyreservesystem.repository.jpa.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.List;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner{
    private final RoomRepository roomRepository;

    @Override
    public void run(String... args) throws Exception {
        if(roomRepository.count() > 0) {
            System.out.println("데이터가 이미 존재합니다. 초기화를 건너뜁니다.");
            return;
        }

        System.out.println("테스트 데이터 초기화 시작");

        List<Room> rooms = Arrays.asList(
                // 강남역 (2개)
                createRoom("에스랩 강남 3호점", "서울 강남구 강남대로78길 14 신화빌딩 3층",
                        "강남역 4번출구 도보 5분으로 접근성이 좋고, 아늑하고 편안한 분위기에서 공부할 수 있습니다! 모든 스터디룸에 화이트보드를 구비해 회의 공간으로도 안성맞춤입니다!",
                        37.4989, 127.0286, 13000, "프리미엄",
                        "화이트보드, 와이파이, 냉난방", "010-1111-2222", "예약 취소는 24시간 전까지 가능합니다.",
                        2, 8, LocalTime.MIN, LocalTime.MAX, "외부 음식물 반입 금지, 정리정돈 필수, 24시간 운영"),

                createRoom("작심 스터디카페 강남역점", "서울 서초구 서초대로 73길 9 타임빌딩 3층",
                        "강남역 9번 출구에서 바로 접근 가능한 최고의 입지! 조용하고 집중하기 좋은 환경을 제공하며, 24시간 운영으로 언제든지 이용 가능합니다. 개인 책상과 화이트보드가 완비되어 있습니다!",
                        37.4973, 127.0280, 15000, "프리미엄",
                        "화이트보드, 와이파이, 개인책상", "010-3333-4444", "예약 후 취소는 영업일 기준 1일 전까지 가능",
                        1, 4,  LocalTime.MIN, LocalTime.MAX, "지문 등록 후 출입 가능, 조용히 이용 부탁드립니다"),

                // 명동역 (2개)
                createRoom("쏠라운지 명동점", "서울 중구 명동10길 52 신한은행 명동역지점 6층",
                        "명동역 8번출구 도보 2분 거리에 위치한 프리미엄 스터디룸! 회의실과 프로젝터를 완비해 팀 프로젝트나 스터디 모임에 최적화되어 있습니다. 깔끔하고 모던한 인테리어로 쾌적한 학습 환경을 제공합니다!",
                        37.5605, 126.9860, 14000, "프리미엄",
                        "회의실, 프로젝터, 와이파이", "010-5555-6666", "취소 가능 기간은 예약일 2일 전까지입니다.",
                        4, 10, LocalTime.of(9,0), LocalTime.of(18,0), "음료류 제외 음식물 반입 금지, 회의실 이용 시 사전 예약 필수"),

                createRoom("그레이프 라운지 명동", "서울 중구 을지로 66",
                        "명동역 4번 출구 근처의 세련된 카페형 스터디 공간! 간이주방과 편안한 소파가 마련되어 있어 장시간 공부에도 지치지 않습니다. 따뜻하고 아늑한 분위기에서 편안하게 학습할 수 있는 공간입니다!",
                        37.5638, 126.9850, 12000, "카페형",
                        "와이파이, 간이주방, 편안한 소파", "010-7777-8888", "취소는 예약 하루 전 6시까지 가능합니다.",
                        2, 10, LocalTime.of(8,0), LocalTime.of(18,0), "바닥이 카펫으로 되어있으니 오염에 주의해주시길 바랍니다"),

                // 이대역 (2개)
                createRoom("플랜에이 이화스터디카페 2센터", "서울 서대문구 이화여대길 75 4층",
                        "이대역 2번 출구에서 367m 거리, 24시간 운영되는 편리한 스터디카페입니다! 개인 책상마다 충분한 공간이 확보되어 있어 집중력을 높일 수 있으며, 냉난방 시설이 완비되어 사계절 쾌적하게 이용 가능합니다!",
                        37.5570, 126.9467, 11000, "일반",
                        "개인 책상, 와이파이, 냉난방", "010-1212-3434", "취소 정책은 별도 문의 바랍니다.",
                        1, 6, LocalTime.MIN, LocalTime.MAX, "개인 공간 존중, 통화는 외부에서 부탁드립니다"),

                createRoom("스터디룸 두드림 신촌이대점", "서울 마포구 신촌로 인근",
                        "이대역과 신촌역 사이에 위치한 넓은 100평 규모의 스터디룸! 화이트보드가 구비되어 그룹 스터디나 팀 프로젝트에 완벽합니다. 깨끗하고 쾌적한 환경에서 효율적으로 공부할 수 있습니다!",
                        37.5565, 126.9458, 10000, "일반",
                        "화이트보드, 와이파이", "010-5656-7878", "예약 취소는 24시간 전까지 가능합니다.",
                        2, 8, LocalTime.MIN, LocalTime.MAX,  "퇴실 시 책상 정리정돈 필수, 쓰레기는 분리수거 부탁드립니다"),

                // 건대입구역 (2개)
                createRoom("작심 스터디카페 건대입구역점", "서울 광진구 건대입구역 6번 출구",
                        "건대입구역 6번 출구에서 도보 2분! 최신 시설과 편안한 의자로 장시간 학습에도 피로가 없습니다. 회의실도 갖춰져 있어 팀 프로젝트나 그룹 스터디에 최적화된 공간입니다!",
                        37.5405, 127.0693, 9000, "일반",
                        "회의실, 와이파이, 편안한 의자", "010-9898-1010", "취소는 예약 하루 전까지 가능",
                        1, 4, LocalTime.of(6,0), LocalTime.of(22,0), "예약 시간 엄수, 지각 시 다음 예약자에게 양보"),

                createRoom("홈워크 스터디카페 건대점", "서울 광진구 능동로13길 75 2층",
                        "건대입구역 2번 출구 근처의 조용하고 편안한 스터디 공간! 개인 책상마다 냉난방이 잘 되어 쾌적한 환경에서 공부할 수 있습니다. 집중력을 방해하지 않는 조용한 분위기가 특징입니다!",
                        37.5398, 127.0685, 8000, "일반",
                        "개인책상, 냉난방, 와이파이", "010-1110-1212", "취소 정책은 사전에 안내됩니다.",
                        1, 6, LocalTime.of(5,0), LocalTime.MAX, "조용한 환경 유지, 음식물 반입 시 냄새 나지 않는 것만 가능"),

                // 잠실역 (2개)
                createRoom("작심 스터디카페 잠실석촌점", "서울 송파구 송파대로 415 지하1층",
                        "잠실역과 석촌역 사이에 위치한 24시간 운영 스터디카페! CCTV가 24시간 가동되어 안전하고, 화이트보드가 구비되어 있어 그룹 스터디에도 적합합니다. 언제든지 편안하게 이용 가능합니다!",
                        37.5133, 127.1002, 12000, "일반",
                        "화이트보드, 와이파이, 24시간 CCTV", "010-1313-1414", "취소는 예약 2일 전까지 가능합니다.",
                        2, 6, LocalTime.MIN, LocalTime.MAX, "24시간 CCTV 녹화 중, 개인 물품 보관에 유의하세요"),

                createRoom("리얼스페이스 잠실점", "서울 송파구 삼전로 삼전빌딩",
                        "삼전역 1번출구 도보 1분 거리의 프리미엄 4인 전용룸! 전용 화장실이 있어 편리하고, 24시간 운영으로 시간 제약 없이 이용 가능합니다. 소규모 팀 프로젝트나 스터디 모임에 최적화된 공간입니다!",
                        37.5145, 127.1058, 13000, "프리미엄",
                        "4인룸, 와이파이, 전용 화장실", "010-1515-1616", "예약 후 24시간 내 취소 가능",
                        2, 4, LocalTime.MIN, LocalTime.MAX,  "4인 전용룸, 전용 화장실 사용 가능, 퇴실 시 청소 필수"),

                // 서울역 (2개)
                createRoom("상연재 서울역점", "서울 중구 한강대로 416 서울스퀘어",
                        "서울역 1번 출구 250m 거리에 위치한 프리미엄 회의실 공간! 음향시설이 완비되어 프레젠테이션이나 세미나에 완벽합니다. 최대 12명까지 수용 가능해 대규모 팀 미팅에도 적합합니다!",
                        37.5547, 126.9707, 15000, "프리미엄",
                        "회의실, 음향시설, 와이파이", "010-1717-1818", "취소 정책은 별도 고지합니다.",
                        4, 12, LocalTime.of(9,0), LocalTime.of(20,0), "회의실 이용 시 음향장비 사용법 숙지 필수, 장비 파손 시 변상"),

                createRoom("투썸플레이스 서울역점", "서울 용산구 한강대로 인근",
                        "서울역 3번 출구 근처의 카페형 스터디 공간! 8인 테이블로 그룹 스터디에 최적화되어 있으며, 주말에도 쾌적하게 이용 가능합니다. 카페 분위기에서 편안하게 공부하고 싶은 분들께 추천합니다!",
                        37.5540, 126.9700, 10000, "카페형",
                        "카페형 공간, 와이파이", "010-1919-2020", "예약 취소는 12시간 전까지 가능",
                        4, 8, LocalTime.of(8,0), LocalTime.of(21,0), "카페 음료 주문 필수(1인 1음료), 조용한 대화는 가능합니다"),

                // 신촌역 (2개)
                createRoom("채움 스터디룸 신촌점", "서울 마포구 신촌로 150 신촌포스빌 2층",
                        "신촌역과 이대역 사이에 위치한 24시간 운영 스터디룸! 제로페이 결제 시 할인 혜택이 있으며, 밤늦게까지 공부하시는 분들을 위한 완벽한 공간입니다. 조용하고 쾌적한 환경에서 집중력을 높일 수 있습니다!",
                        37.5559, 126.9369, 11000, "일반",
                        "24시간 운영, 와이파이, 제로페이", "010-2121-2222", "예약 후에는 24시간 내 취소 가능",
                        1, 6, LocalTime.MIN, LocalTime.MAX, "제로페이 결제 시 할인, 24시간 운영, 야간 이용 시 조용히 해주세요"),

                createRoom("랭스터디카페 신촌점", "서울 서대문구 신촌역 근처",
                        "신촌역 인근의 앤틱한 분위기가 돋보이는 카페형 스터디 공간! 독특한 인테리어와 편안한 분위기에서 여유롭게 공부할 수 있습니다. 카페 메뉴도 다양하게 제공되어 장시간 학습에도 지루하지 않습니다!",
                        37.5550, 126.9360, 12000, "카페형",
                        "앤틱 인테리어, 와이파이, 카페 메뉴", "010-2323-2424", "취소 정책 별도 문의",
                        2, 8, LocalTime.of(9,0), LocalTime.of(23,0), "앤틱 가구 사용 중이니 조심히 사용해주세요, 음료 주문 권장")
        );




        roomRepository.saveAll(rooms);
        System.out.println("스터디카페 데이터" + rooms.size() + "개 추가 완료");
    }


    private Room createRoom(String name, String address, String content,
                            double lat, double lng, int price, String type,
                            String facilities, String contactInfo, String reservePolicy,
                            Integer minCapacity, Integer maxCapacity,
                            LocalTime openTime, LocalTime closeTime,
                            String internalPolicy) {
        Room room = new Room();
        room.setRoomName(name);
        room.setRoomAddress(address);
        room.setRoomContent(content);
        room.setLatitude(lat);
        room.setLongitude(lng);
        room.setRoomPrice(price);
        room.setRoomType(type);
        room.setFacilities(facilities);
        room.setContactInfo(contactInfo);
        room.setReservePolicy(reservePolicy);
        room.setMinCapacity(minCapacity);
        room.setMaxCapacity(maxCapacity);
        room.setOpenTime(openTime);
        room.setCloseTime(closeTime);
        room.setOpen24Hours(openTime.equals(LocalTime.MIN) && closeTime.equals(LocalTime.MAX));
        room.setInternalPolicy(internalPolicy);

        return room;
    }

}
