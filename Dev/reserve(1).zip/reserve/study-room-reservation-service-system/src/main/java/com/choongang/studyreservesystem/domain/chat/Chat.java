package com.choongang.studyreservesystem.domain.chat;

import com.choongang.studyreservesystem.dto.chat.ChatDto;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Getter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Chat {

    @Id
    @Column(name = "CHAT_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long chatId;

    @Column(name = "USER_ID", nullable = false)
    private Long userId;

    @Column(name = "SENDER_NAME", nullable = false)
    private String senderName;

    @Column(name = "MESSAGE", nullable = false)
    private String message;

    @ManyToOne
    @JoinColumn(name = "CHAT_ROOM_ID", nullable = false)
    private ChatRoom chatRoom;

    @Column(name = "CREATE_TIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @Builder.Default
    private LocalDateTime createTime = LocalDateTime.now();


    public static Chat createChat(ChatDto chatDto,ChatRoom chatRoom) {
        return Chat.builder()
                .senderName(chatDto.getSenderName())
                .userId(chatDto.getSenderId())
                .message(chatDto.getMessage())
                .chatRoom(chatRoom)
                .build();
    }
}
