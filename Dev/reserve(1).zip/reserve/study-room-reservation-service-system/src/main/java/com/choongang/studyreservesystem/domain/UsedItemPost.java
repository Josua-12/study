package com.choongang.studyreservesystem.domain;

import com.choongang.studyreservesystem.domain.enums.UsedItemStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.SQLRestriction;

import java.util.ArrayList;
import java.util.List;

@Table(name = "used_item_posts")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@SQLDelete(sql = "UPDATE useditempost SET deleted = true WHERE id = ?") //delete 쿼리 발생 시 deleted 값을 true로 업데이트
@SQLRestriction("deleted = false")   // 이 엔티티를 조회하는 JPA 쿼리에 자동으로 WHERE deleted = false 조건을 추가
public class UsedItemPost extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(nullable = false, length = 1000)
    private String content;

    @Column(nullable = false)
    private Integer price;      // 보통 가격은 인트를 안쓰는 게 보통이지만 중고거래이기 때문에 인티저 사용 필요하다면 수정

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private UsedItemStatus status = UsedItemStatus.SELLING;     // 디폴트 값을 SELLING으로 지정

    private String location;    //거래 희망 장소

    @Builder.Default
    private Long likeCount = 0L;

    @Builder.Default
    private Long viewCount = 0L;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "author_id", nullable = false)
    private User author;

    // 댓글을 어떻게 할지 정한 후 구현자에 생각에 따라 수정
    @OneToMany(mappedBy = "usedItemPost", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Comment> comments = new ArrayList<>();     // 지금 만들어진 댓글 엔티티 재활용을 기준으로 만듬 - 재활용 시 기존 댓글 수정 필요



//============== 엔티티 내에서 해결 가능한 비즈니스 로직 =====================
    public void increaseViewCount() {
        this.viewCount++;
    }

    public void updateLikeCount(Long newLikeCount) {
        this.likeCount = newLikeCount;
    }

    //상태 업데이트
    public void updateStatus(UsedItemStatus status) {
        this.status = status;
    }

    // 업데이트 로직
    public void updateItem(String title, String content, Integer price, String location) {
        this.title = title;
        this.content = content;
        this.price = price;
        this.location = location;
    }



}
