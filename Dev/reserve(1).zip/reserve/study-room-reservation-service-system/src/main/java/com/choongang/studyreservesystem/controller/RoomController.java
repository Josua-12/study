package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.dto.RoomSearchConditionDto;
import com.choongang.studyreservesystem.dto.RoomSummaryDto;
import com.choongang.studyreservesystem.dto.review.ReviewResponseDTO;
import com.choongang.studyreservesystem.security.CustomUserDetails;
import com.choongang.studyreservesystem.service.ReviewService;
import com.choongang.studyreservesystem.service.jpa.RoomService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@Validated
@RequiredArgsConstructor
@RequestMapping("/room")
public class RoomController {
    private final RoomService roomService;
    private final ReviewService reviewService;

    @Value("${kakao.js.key}")
    private String kakaoJsKey;

    @GetMapping("/list")
    public String listPage(@Valid @ModelAttribute RoomSearchConditionDto cond, Model model) {
        List<RoomSummaryDto> results = roomService.findAllRooms(cond);
        model.addAttribute("cond", cond);
        model.addAttribute("results", results);
        model.addAttribute("kakaoJsKey", kakaoJsKey);
        return "room/mapInfo";
    }

    @GetMapping(value = "/list/data", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<RoomSummaryDto> listData(@Valid @ModelAttribute RoomSearchConditionDto cond) {
        return roomService.findAllRooms(cond);
    }

    @GetMapping("/{id}")
    public String detail(@PathVariable Long id, Model model, @AuthenticationPrincipal CustomUserDetails userDetails){
        model.addAttribute("room", roomService.findRoom(id));
        model.addAttribute("kakaoJsKey", kakaoJsKey);
        if (userDetails != null) {
            model.addAttribute("currentUser", userDetails.getUser());
        }
        List<ReviewResponseDTO> reviews = reviewService.getReviewByRoomId(id);
        model.addAttribute("reviews", reviews);

        return "room/roomDetails";
    }


}