package com.choongang.studyreservesystem.repository.jpa.Impl;

import com.choongang.studyreservesystem.dto.RoomSearchConditionDto;
import com.choongang.studyreservesystem.dto.RoomSummaryProjection;
import com.choongang.studyreservesystem.repository.jpa.RoomRepositoryCustom;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class RoomRepositoryImpl implements RoomRepositoryCustom {
    private final EntityManager em;

    @Override
    public Page<RoomSummaryProjection> search(RoomSearchConditionDto cond, Pageable pageable) {
        StringBuilder sql = new StringBuilder("""
      SELECT r.room_id   AS roomId,
             r.room_name AS roomName,
             r.room_address AS shortAddress,
             r.latitude  AS latitude,
             r.longitude AS longitude,
             r.room_price AS price,
             r.room_type  AS roomType,
             r.room_content AS content,
             0 AS distanceMeters
      FROM rooms r
      WHERE 1=1
    """);
        if (cond.getKeyword() != null && !cond.getKeyword().isBlank()) {
            sql.append(" AND (r.room_name LIKE :keyword OR r.room_address LIKE :keyword) ");
        }
        // 정렬/페이징
        String orderClause = " ORDER BY r.room_id DESC ";
        Query q = em.createNativeQuery(sql + orderClause)
                .setFirstResult((int) pageable.getOffset())
                .setMaxResults(pageable.getPageSize());

        if (cond.getKeyword() != null && !cond.getKeyword().isBlank()) {
            q.setParameter("keyword", "%" + cond.getKeyword() + "%");
        }

        @SuppressWarnings("unchecked")
        List<Object[]> rows = q.getResultList();
        List<RoomSummaryProjection> content = rows.stream()
                .map(ProjectionImpl::from)
                .collect(java.util.stream.Collectors.toList());

        // count 쿼리
        Query cq = em.createNativeQuery("SELECT COUNT(*) FROM (" + sql + ") t");
        if (cond.getKeyword() != null && !cond.getKeyword().isBlank()) {
            cq.setParameter("keyword", "%" + cond.getKeyword() + "%");
        }
        long total = ((Number) cq.getSingleResult()).longValue();

        return new PageImpl<>(content, pageable, total);
    }

    @Override
    public Page<RoomSummaryProjection> findNear(double lat, double lng, int radius, Pageable pageable) {
        String sql = """
          SELECT r.room_id   AS roomId,
                 r.room_name AS roomName,
                 r.room_address AS shortAddress,
                 r.latitude  AS latitude,
                 r.longitude AS longitude,
                 r.room_price AS price,
                 r.room_type  AS roomType,
                 r.room_content AS content,
                 CAST(ST_Distance_Sphere(
                    POINT(:lng, :lat),
                    POINT(r.longitude, r.latitude)
                 ) AS SIGNED) AS distanceMeters
          FROM rooms r
          WHERE ST_Distance_Sphere(
            POINT(:lng, :lat),
            POINT(r.longitude, r.latitude)
          ) <= :radius
          ORDER BY distanceMeters ASC
        """;
        Query q = em.createNativeQuery(sql)
                .setParameter("lat", lat)
                .setParameter("lng", lng)
                .setParameter("radius", radius)
                .setFirstResult((int) pageable.getOffset())
                .setMaxResults(pageable.getPageSize());

        @SuppressWarnings("unchecked")
        List<Object[]> rows = q.getResultList();
        List<RoomSummaryProjection> content = rows.stream()
                .map(ProjectionImpl::fromWithDistance)
                .collect(java.util.stream.Collectors.toList());

        // 총계: 간단히 동일 조건으로 count
        Query cq = em.createNativeQuery("""
          SELECT COUNT(*)
          FROM rooms r
          WHERE ST_DistanceSphere(
            POINT(:lng, :lat),
            POINT(r.longitude, r.latitude)
          ) <= :radius
        """)
        .setParameter("lat", lat)
        .setParameter("lng", lng)
        .setParameter("radius", radius);

        long total = ((Number) cq.getSingleResult()).longValue();
        return new PageImpl<>(content, pageable, total);
    }

    @Getter
    @AllArgsConstructor
    static class ProjectionImpl implements RoomSummaryProjection {
        Long roomId;
        String roomName;
        String shortAddress;
        Double latitude;
        Double longitude;
        Integer price;
        String roomType;
        Integer distanceMeters;
        String content;

        static ProjectionImpl from(Object[] r) {
            return new ProjectionImpl(
                toLong(r[0]), (String) r[1], (String) r[2],
                toDouble(r[3]), toDouble(r[4]), toInt(r[5]),
                (String) r[6], toInt(r[8]), (String) r[7]
            );
        }
        static ProjectionImpl fromWithDistance(Object[] r) {
            return new ProjectionImpl(
                toLong(r[0]), (String) r[1], (String) r[2],
                toDouble(r[3]), toDouble(r[4]), toInt(r[5]),
                (String) r[6], toInt(r[8]), (String) r[7]
            );
        }

        private static Long toLong(Object v) {
            return v == null ? null : ((Number) v).longValue();
        }

        private static Double toDouble(Object v){
            return v == null ? null : ((Number)v).doubleValue();
        }

        private static Integer toInt(Object v){
            return v == null ? null : ((Number)v).intValue();
        }
    }
}
