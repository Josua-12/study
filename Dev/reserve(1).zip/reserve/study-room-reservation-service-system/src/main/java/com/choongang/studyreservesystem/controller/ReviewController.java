package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.dto.RoomSummaryDto;
import com.choongang.studyreservesystem.dto.review.ReviewResponseDTO; // ReviewResponseDTO import 추가
import com.choongang.studyreservesystem.dto.review.ReviewSaveDto;
import com.choongang.studyreservesystem.dto.review.ReviewUpdateDto;
import com.choongang.studyreservesystem.security.CustomUserDetails;
import com.choongang.studyreservesystem.service.ReservationService;
import com.choongang.studyreservesystem.service.ReviewService;
import com.choongang.studyreservesystem.service.jpa.RoomService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List; // List import 추가

@Controller
@RequiredArgsConstructor
@RequestMapping("/review")
public class ReviewController {

    private final ReviewService reviewService;
    private final RoomService roomService;
    private final ReservationService reservationService;

    @GetMapping("/write/{roomId}")
    public String showReviewForm(@PathVariable Long roomId, Model model,
                                 @AuthenticationPrincipal CustomUserDetails userDetails,
                                 RedirectAttributes redirectAttributes) {

        if (userDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인 후 리뷰를 작성할 수 있습니다.");
            return "redirect:/login";
        }

        String username = userDetails.getUsername();

        boolean hasReservations = reservationService.hasCompletedReservations(roomId, username);
        if (!hasReservations) {
            redirectAttributes.addFlashAttribute("errorMessage", "해당 스터디룸 이용 내역이 없습니다.");
            return "redirect:/review/list/" + roomId;
        }

        boolean hasReviewed = reviewService.hasUserAlreadyReviewed(roomId, username);
        if (hasReviewed) {
            redirectAttributes.addFlashAttribute("errorMessage", "이미 이 스터디룸에 대한 리뷰를 작성하셨습니다.");
            return "redirect:/review/list/" + roomId;
        }

        RoomSummaryDto roomDto = roomService.findRoom(roomId);

        String roomName = roomDto != null ? roomDto.getRoomName() : "알 수 없는 스터디룸";

        ReviewSaveDto reviewSaveDto = new ReviewSaveDto();
        reviewSaveDto.setRoomId(roomId);

        model.addAttribute("roomId", roomId);
        model.addAttribute("roomName", roomName); // Room Name 모델에 추가
        model.addAttribute("reviewSaveDto", reviewSaveDto);

        return "review/reviewForm";
    }

    @PostMapping("/create")
    public String createReview(@Valid @ModelAttribute ReviewSaveDto reviewSaveDto,
                               BindingResult bindingResult,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes) {

        if (userDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인 세션이 만료되었습니다.");
            return "redirect:/login";
        }

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "입력 내용을 확인해 주세요.");
            return "redirect:/review/write/" + reviewSaveDto.getRoomId();
        }

        try {
            User user = userDetails.getUser();
            reviewService.saveReview(reviewSaveDto, user);

            redirectAttributes.addFlashAttribute("successMessage", "리뷰가 성공적으로 작성되었습니다! 🎉");
            return "redirect:/review/list/" + reviewSaveDto.getRoomId();

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "리뷰 작성 중 오류가 발생했습니다.");
            return "redirect:/review/list/" + reviewSaveDto.getRoomId();
        }
    }

    @GetMapping("/list/{roomId}")
    public String getReviewList(@PathVariable Long roomId, Model model) {

        RoomSummaryDto roomDto = roomService.findRoom(roomId);
        String roomName = roomDto != null ? roomDto.getRoomName() : roomId + "번 스터디룸";
        List<ReviewResponseDTO> reviews = reviewService.getReviewByRoomId(roomId);

        model.addAttribute("roomId", roomId);
        model.addAttribute("roomName", roomName); // 🌟 Model에 roomName 추가 (필수)
        model.addAttribute("reviews", reviews);

        return "review/reviewList";
    }

    @PostMapping("/delete/{reviewId}")
    public String deleteReview(@PathVariable Long reviewId,
                               @RequestParam("roomId") Long roomId,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes) {
        if (userDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
            return "redirect:/login";
        }

        try {
            reviewService.deleteReview(reviewId, userDetails.getUser());
            redirectAttributes.addFlashAttribute("successMessage", "리뷰가 삭제가 완료되었습니다.");
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "리뷰 삭제 중 오류가 발생했습니다.");
        }

        return "redirect:/review/list/" + roomId;
    }

    @GetMapping("/edit/{reviewId}")
    public String showEditForm(@PathVariable Long reviewId,
                               Model model,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes) {
        if (userDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
            return "redirect:/login";
        }

        try {
            ReviewResponseDTO reviewDto = reviewService.getReviewById(reviewId);
            if (!reviewDto.getUserId().equals(userDetails.getUser().getId()) && !userDetails.getUser().getRole().equals("ROLE_ADMIN")) {
                redirectAttributes.addFlashAttribute("errorMessage", "수정 권한이 없습니다.");
                return "redirect:/review/list/" + reviewDto.getRoomId();
            }

            ReviewUpdateDto reviewUpdateDto = new ReviewUpdateDto();
//            reviewUpdateDto.setReviewId(reviewId);
//            reviewUpdateDto.setEditorId(userDetails.getId());
            reviewUpdateDto.setRating(reviewDto.getRating());
            reviewUpdateDto.setContent(reviewDto.getContent());

            RoomSummaryDto roomDto = roomService.findRoom(reviewDto.getRoomId());
            ReviewResponseDTO review = reviewService.getReviewById(reviewId);



            model.addAttribute("reviewUpdateDto", reviewUpdateDto);
            model.addAttribute("reviewId", reviewId);
            model.addAttribute("roomId", reviewDto.getRoomId()); // 폼에서 '취소' 버튼용
            model.addAttribute("roomName", roomDto.getRoomName());
            model.addAttribute("form", ReviewUpdateDto.builder()
                    .content(review.getContent())
                    .rating(review.getRating())
                    .build());

            return "review/reviewEditForm";

        }catch (IllegalStateException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/review/edit/" + reviewId;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/";
        }
    }

    @PostMapping("/update/{reviewId}")
    public String updateReview(@PathVariable Long reviewId,
                               @Valid @ModelAttribute("reviewUpdateDto") ReviewUpdateDto reviewUpdateDto,
                               BindingResult bindingResult,
                               @AuthenticationPrincipal CustomUserDetails userDetails,
                               RedirectAttributes redirectAttributes,
                               Model model) {
        // 0) 로그인 체크
        if (userDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인이 필요합니다.");
            return "redirect:/login";
        }

        // 1) 서버 신뢰값 보정 (폼 조작/누락 대비)
//        reviewUpdateDto.setReviewId(reviewId);
//        reviewUpdateDto.setEditorId(userDetails.getId());

        // 2) 검증 에러 시 같은 폼 뷰로 'forward'
        if (bindingResult.hasErrors()) {
            // 폼 다시 그릴 때 필요한 부가 모델값 채우기
            // (reviewService에서 조회해서 roomName/roomId를 가져오거나, 서비스에서 반환한 DTO를 쓰세요)
            var current = reviewService.getReviewById(reviewId);
            model.addAttribute("roomName", current.getRoomName());
            model.addAttribute("roomId", current.getRoomId());
            model.addAttribute("reviewId", reviewId);
            model.addAttribute("errorMessage", "입력 내용을 확인해주세요.");
            return "review/reviewEditForm"; // ← redirect 아님
        }

        try {
            ReviewResponseDTO updatedReview = reviewService.updateReview(reviewId, reviewUpdateDto, userDetails.getUser());

            redirectAttributes.addFlashAttribute("successMessage", "리뷰가 성공적으로 수정되었습니다.");

            return "redirect:/review/list/" + updatedReview.getRoomId();
        } catch (IllegalArgumentException | EntityNotFoundException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/review/edit/" + reviewId;
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "리뷰 수정 중 오류가 발생했습니다.");
            return "redirect:/review/edit/" + reviewId;
        }
    }
}