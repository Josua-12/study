package com.choongang.studyreservesystem.dto.report;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ReportResponseDto {

    @NotNull(message = "신고 대상의 리뷰 id는 필수입니다.")
    private Long reviewId;

    @NotBlank(message = "신고 사유를 적으세요.")
    @Size(max = 500, message = "500자 이내로 적으세요.")
    private String reason;
}
