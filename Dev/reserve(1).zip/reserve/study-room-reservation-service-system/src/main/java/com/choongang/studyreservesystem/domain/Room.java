package com.choongang.studyreservesystem.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;

@Entity
@Table(name = "rooms")
@Getter
@Setter
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "room_id")
    private Long roomId;

    @Column(nullable = false)
    private String roomName;

    @Column(nullable = false)
    private String roomAddress;

    @Column(nullable = false)
    private String roomContent;

    private Double latitude;    // 위도
    private Double longitude;   // 경도
    private Integer roomPrice;
    private String roomType;

    private String facilities;
    private String contactInfo;
    private String reservePolicy;
    private Integer minCapacity;
    private Integer maxCapacity;
    @Column(nullable = false)
    private LocalTime openTime; //오픈시간
    @Column(nullable = false)
    private LocalTime closeTime; //마감시간
    private boolean isOpen24Hours; // 24시간 운영 여부
    private String internalPolicy;
}
