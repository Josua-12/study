package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.dto.UserResponseDto;
import com.choongang.studyreservesystem.dto.chat.*;
import com.choongang.studyreservesystem.infrastructure.socket.ChatService;
import com.choongang.studyreservesystem.security.CustomUserDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Queue;

@Slf4j
@Controller
public class ChatController {

    private final ChatService chatService;

    @Autowired
    public ChatController(ChatService chatService) {
        this.chatService = chatService;
    }

    @GetMapping("/chat")
    public String showChatHomePage(@AuthenticationPrincipal CustomUserDetails customUserDetails,
                                   Model model, RedirectAttributes redirectAttributes) {
        if (customUserDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인 후 리뷰를 작성할 수 있습니다.");
            return "redirect:/login";
        }
        List<ChatRoomResponseDto> chatRooms = chatService.getUserChatRooms(customUserDetails.getId());
        model.addAttribute("chatRooms", chatRooms);
        return "chat/chat-list";
    }


    @GetMapping("/chat/{roomId}")
    public String showChatPage(@PathVariable Long roomId, Model model,
                               @AuthenticationPrincipal CustomUserDetails customUserDetails,
                               RedirectAttributes redirectAttributes) {
        if (customUserDetails == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "로그인 후 리뷰를 작성할 수 있습니다.");
            return "redirect:/login";
        }
        Queue<ChatHistoryDto> chatHistory = chatService.getChatHistory(roomId);
        List<ChatUserResponseDto> roomParticipants = chatService.getRoomParticipants(roomId);

        ChatRoomResponseDto chatRoom = chatService.getChatRoom(roomId);
        model.addAttribute("roomId", roomId);
        model.addAttribute("chatHistory", chatHistory);
        model.addAttribute("participants", roomParticipants);
        model.addAttribute("chatRoom", chatRoom);
        return "chat/chat-room";
    }

    @PostMapping("/chat/create/room")
    public String createChatRoom(@ModelAttribute ChatRoomCreateDto chatRoomCreateDto,
                                 @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        log.info("createChatRoom {}", chatRoomCreateDto);
        chatRoomCreateDto.setMasterId(customUserDetails.getId());
        chatRoomCreateDto.setMasterName(customUserDetails.getUsername());
        Long room = chatService.createRoom(chatRoomCreateDto);
        return "redirect:/chat/" + room;
    }

    @PostMapping("/chat/invite/user")
    public String inviteUserToChatRoom(@ModelAttribute InviteChatRoomDto dto,
                                       @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        dto.setMasterId(customUserDetails.getId());
        log.info("inviteUserToChatRoom {}", dto);
        Long toRoom = chatService.inviteUserToRoom(dto);
        return "redirect:/chat/" + toRoom;
    }

    @PostMapping("/chat/leave/room/{roomId}")
    public String leaveChatRoom(@PathVariable Long roomId,
                                @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        log.info("leaveChatRoom roomId: {}, userId: {}", roomId, customUserDetails.getId());
        chatService.leaveRoom(roomId, customUserDetails.getId());
        return "redirect:/chat";
    }
}
