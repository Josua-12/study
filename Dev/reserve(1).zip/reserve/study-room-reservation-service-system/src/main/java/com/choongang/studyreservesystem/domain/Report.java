package com.choongang.studyreservesystem.domain;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
@Table(name="report")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Report extends BaseEntity{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name= "reporter_user_id", nullable = false)
    private User reporterUser;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name ="target_review_id", nullable = false)
    private Review targetReview;

    @Column(length = 500 , nullable = false)
    private String reason;

    //처리 상태 PENDING =>대기 , PROCESSED =>처리 완료 , REJECTED =>거부
    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ReportStatus status = ReportStatus.PENDING;

    private LocalDateTime reportedAt;

    public  enum ReportStatus{
        PENDING ,PROCESSED,REJECTED
    }
}
