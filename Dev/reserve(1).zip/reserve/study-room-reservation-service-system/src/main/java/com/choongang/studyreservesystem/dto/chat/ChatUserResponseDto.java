package com.choongang.studyreservesystem.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatUserResponseDto {

    private String username;
    private Long userId;
}
