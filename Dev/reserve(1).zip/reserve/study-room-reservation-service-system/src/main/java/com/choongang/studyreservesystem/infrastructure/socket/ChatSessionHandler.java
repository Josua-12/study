//package com.choongang.studyreservesystem.infrastructure.socket;
//
//import com.choongang.studyreservesystem.dto.chat.ChatDto;
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.stereotype.Component;
//import org.springframework.web.socket.TextMessage;
//import org.springframework.web.socket.WebSocketSession;
//
//import java.io.IOException;
//import java.util.Collections;
//import java.util.Set;
//import java.util.concurrent.ConcurrentHashMap;
//
//@Slf4j
//@Component
//public class ChatSessionHandler {
//
//    private final ConcurrentHashMap<String, WebSocketSession> sessionPool = new ConcurrentHashMap<>();
//    private final ConcurrentHashMap<Long, Set<String>> roomSessions = new ConcurrentHashMap<>();
//    private final ObjectMapper objectMapper;
//
//    public ChatSessionHandler(ObjectMapper objectMapper) {
//        this.objectMapper = objectMapper.copy();
//    }
//
//    public void addSession(WebSocketSession session) {
//        sessionPool.put(session.getId(), session);
//        log.info("Session added to pool: {}", session.getId());
//    }
//
//    public void removeSession(String sessionId) {
//        if (sessionPool.containsKey(sessionId)) {
//            sessionPool.remove(sessionId);
//            roomSessions.values().forEach(sessionSet -> sessionSet.remove(sessionId));
//            log.info("Session removed from pool and all rooms: {}", sessionId);
//        }
//    }
//
//    public void registerRoom(Long chatRoomId, String sessionId) {
//        roomSessions.computeIfAbsent(chatRoomId, k ->
//                Collections.synchronizedSet(ConcurrentHashMap.newKeySet())
//        ).add(sessionId);
//
//        log.info("Session {} registered to room {}", sessionId, chatRoomId);
//    }
//
//    public void unregisterRoom(Long chatRoomId, String sessionId) {
//        if (roomSessions.containsKey(chatRoomId)) {
//            roomSessions.get(chatRoomId).remove(sessionId);
//            log.info("Session {} unregistered from room {}", sessionId, chatRoomId);
//        }
//    }
//
//    public void broadcastMessage(Long chatRoomId, ChatDto chatDto) {
//        Set<String> targetSessions = roomSessions.getOrDefault(chatRoomId, Collections.emptySet());
//        TextMessage textMessage;
//        try {
//            String jsonPayload = objectMapper.writeValueAsString(chatDto);
//            textMessage = new TextMessage(jsonPayload);
//        } catch (JsonProcessingException e) {
//            log.error("Failed to serialize ChatDto for room {}: {}", chatRoomId, e.getMessage());
//            return;
//        }
//
//        for (String sessionId : targetSessions) {
//            WebSocketSession session = sessionPool.get(sessionId);
//            if (session != null && session.isOpen()) {
//                try {
//                    session.sendMessage(textMessage);
//                } catch (IOException e) {
//                    log.error("Failed to send message to session {}: {}", sessionId, e.getMessage());
//                    removeSession(sessionId);
//                }
//            } else if (session != null) {
//                removeSession(sessionId);
//            }
//        }
//    }
//
//}
