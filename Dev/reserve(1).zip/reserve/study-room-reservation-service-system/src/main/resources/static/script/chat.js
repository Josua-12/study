// /js/chat.js 파일
document.addEventListener('DOMContentLoaded', () => {
    // 1. DOM 요소 및 전역 변수 설정
    const messageContainer = document.getElementById('messages-container');
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-btn');

    // 이 변수들은 chat-room.html의 <script th:inline="javascript">에서 넘어온다.
    // const roomId, currentUserId, currentUsername

    let stompClient = null;
    const socketUrl = "/ws/chat"; // 네 WebSocket 엔드포인트!

    // 2. 초기 스크롤: 메시지 컨테이너를 맨 아래로 이동
    // 메시지가 로드된 후 이 부분이 실행되어야 한다.
    setTimeout(() => {
        messageContainer.scrollTop = messageContainer.scrollHeight;
    }, 100);

    // 3. WebSocket 연결 함수
    function connect() {
        const socket = new SockJS(socketUrl);
        stompClient = Stomp.over(socket);

        stompClient.connect({}, frame => {
            console.log('STOMP: Connected to ' + frame.server);

            stompClient.subscribe('/topic/chat/room/' + roomId, function (message) {
                showMessage(JSON.parse(message.body));
            });

            // 5. 방 입장 메시지 전송 (ENTER 타입)
            stompClient.send("/app/chat/message", {}, JSON.stringify({
                'chatType': 'ENTER',
                'chatRoomId': roomId,
                'senderId': currentUserId,
                'senderName': currentUsername
            }));

        }, error => {
            console.error('STOMP Connection Error: ' + error);
        });
    }

    // 6. 🔥🔥🔥 메시지 전송 함수 (TALK 타입) 🔥🔥🔥
    function sendMessage() {
        const message = messageInput.value.trim();
        if (message && stompClient && stompClient.connected) {
            const chatMessage = {
                'chatType': 'TALK',
                'chatRoomId': roomId,
                'senderId': currentUserId,
                'senderName': currentUsername,
                'message': message,
            };

            // 서버의 메시지 핸들러 엔드포인트로 전송
            stompClient.send("/app/chat/message", {}, JSON.stringify(chatMessage));
            messageInput.value = ''; // 입력창 초기화
        } else if (!stompClient || !stompClient.connected) {
            console.error("Websocket is not connected.");
            alert("채팅 서버와 연결되지 않았습니다. 잠시 후 다시 시도하세요.");
        }
    }

    // 7. 메시지 표시 함수
    function showMessage(message) {
        // message 객체는 서버에서 보내준 ChatHistoryDto와 유사해야 한다.
        const isMyMessage = message.senderId == currentUserId;
        let timeString;

        // 서버에서 createTime을 ISO String으로 주었다고 가정하고 포맷팅
        try {
            timeString = message.createTime ? new Date(message.createTime).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }) : new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
        } catch (e) {
            // 시간 포맷 에러가 나면 그냥 현재 시간을 쓴다.
            timeString = new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
        }

        const html = `
            <div class="message-row ${isMyMessage ? 'my-message' : 'other-message'}">
                <div class="message-content-wrapper">
                    <div class="message-info">
                        ${isMyMessage ? '' : `<span class="sender">${message.senderName || '알 수 없음'}</span>`}
                        <span class="time">${timeString}</span>
                    </div>
                    <div class="message-bubble">${message.message}</div>
                </div>
            </div>
        `;

        messageContainer.insertAdjacentHTML('beforeend', html);
        messageContainer.scrollTop = messageContainer.scrollHeight; // 스크롤 맨 아래로
    }

    // 8. 이벤트 리스너 등록
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault(); // 기본 Enter 동작(줄바꿈) 방지
            sendMessage();
        }
    });

    // 9. 페이지 로드 시 연결 시작
    connect();
});