package com.example.mvcs3simple;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mvcs3simpleApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mvcs3simpleApplication.class, args);
	}

}
