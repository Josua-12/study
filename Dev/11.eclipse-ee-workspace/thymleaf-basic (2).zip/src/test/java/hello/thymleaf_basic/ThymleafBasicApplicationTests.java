package hello.thymleaf_basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymleafBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
