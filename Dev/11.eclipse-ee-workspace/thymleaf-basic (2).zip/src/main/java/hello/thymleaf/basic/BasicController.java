package hello.thymleaf.basic;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller // Spring MVC 컨트롤러로 선언
@RequestMapping("/basic") // 이 컨트롤러의 모든 URL은 /basic으로 시작
public class BasicController {

	// XSS 공격 방지를 위한 기본 처리
	@GetMapping("/text-basic")	// GET /basic/text-basic
	public String textBasic(Model model) {
		
		model.addAttribute("data", "Hello <b>Spring<b>!");
		return "basic/text-basic";
	}
	
	
	@GetMapping("/text-unescaped")
	public String textUnescaped(Model model) {
		model.addAttribute("data", "Hello <b>Spring<b>!");
		return "basic/text-unescaped";
	}
}
