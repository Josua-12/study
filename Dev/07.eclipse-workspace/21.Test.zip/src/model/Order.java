package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Order {
    private String orderId;              // 주문 ID
    private Customer customer;           // 주문 고객
    private ArrayList<CartItem> items;   // 주문 상품들
    private LocalDateTime orderDate;     // 주문일시
    private int totalAmount;            // 총 주문금액
    private String status;              // 주문 상태
    
    

	public Order(String orderId, Customer customer, ArrayList<CartItem> items, LocalDateTime orderDate,
			String status) {
		this.orderId = orderId;
		this.customer = customer;
		this.items = items;
		this.orderDate = orderDate;
		this.status = "주문 완료";
		calculateTotalAmount();
	}


	// 총 금액 계산
	private void calculateTotalAmount() {
		int sum = 0;
        for (CartItem item : items) {
            sum += item.getTotalPrice();
        }
        this.totalAmount = sum;
	}
	public String getOrderId() { return orderId; }
	public Customer getCustomer() { return customer; }
	public ArrayList<CartItem> getItems() { return items; }
	public LocalDateTime getOrderDate() { return orderDate; }
	public int getTotalAmount() { return totalAmount; }
	public String getStatus() { return status; }	
	
	public void updateStatus(String newStatus) {
        this.status = newStatus;
	}
	
	@Override
    public String toString() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("주문번호: %s, 고객: %s, 주문일시: %s, 상태: %s\n",
                orderId, customer.getName(), orderDate.format(formatter), status));
        sb.append("상품 목록:\n");
        for (CartItem item : items) {
            sb.append("  - ").append(item.toString()).append("\n");
        }
        sb.append(String.format("총 주문금액: %,d원", totalAmount));
        return sb.toString();
    }
}