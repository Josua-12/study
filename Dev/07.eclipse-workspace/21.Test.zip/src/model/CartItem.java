package model;

// 장바구니
public class CartItem {
    private Product product;  // 상품
    private int quantity;    // 수량
    
    
    
    public CartItem(Product product, int quantity) {
		//super();
		this.product = product;
		this.quantity = quantity;
	}
    
	public Product getProduct() { return product; }

	public int getQuantity() { return quantity; }

	public void addQuantity(int amount) {
    	// 수량 증가
		if(amount > 0) {
			this.quantity += amount;
		}
    }
	
    public int getTotalPrice() { // 총 가격 계산
    // toString()으로 상품정보와 총액 표시
    	return product.getPrice() * quantity;
    }

	@Override
	public String toString() {
		return String.format("- %s x %d개 = %,d원",
	            product.getName(), quantity, getTotalPrice());
	}
   
    
}