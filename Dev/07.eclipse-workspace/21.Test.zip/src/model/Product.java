package model;

import exception.InsufficientStockException;

public class Product {
    private String productId;       // 상품 ID
    private String name;           // 상품명
    private int price;            // 가격
    private int stock;            // 재고
    private String category;      // 카테고리
    private double rating;        // 평점 (0.0 ~ 5.0)
    private int reviewCount;      // 리뷰 개수
    
    // 생성자, getter 메서드들
    public Product(String productId, String name, int price, int stock, String category, double rating,
			int reviewCount) {
		super();
		this.productId = productId;
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.category = category;
		this.rating = 0.0;
		this.reviewCount = 0;
	}
    
    public String getProductId() {return productId;}
	public String getName() {return name;}
	public int getPrice() {return price;}
	public int getStock() {return stock;}
	public String getCategory() {return category;}
	public double getRating() {return rating;}
	public int getReviewCount() {return reviewCount;}

	// 재고 감소
	public void reduceStock(int quantity) throws InsufficientStockException {
    	if(stock < quantity) {
    		throw new InsufficientStockException("재고 부족");
    	}
    	stock -= quantity;
    }
    
	//재고 추가
	public void addStock(int quantity) {
		if(quantity > 0) {
			stock += quantity;
		}
    }
	
	// 재고 있음 여부
    public boolean isInStock() {
    	return stock > 0;
    }
    
    // 재고 5개 이하 여부
    public boolean isLowStock() {// 재고 5개 이하 체크 (요구사항)
    	return stock <= 5 && this.stock > 0;
    }
    
    // 리뷰 추가 및 평점 평균 갱신
    public void addReview(double newRating) {
    	if (newRating < 0.0 || newRating > 5.0) return;

        double totalRating = rating * reviewCount;
        reviewCount++;
        rating = (totalRating + newRating) / reviewCount;
    }

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return String.format("%s (%s) - %,d원 [%d개 남음, 평점 %.1f (%d개 리뷰)]",
	            name, category, price, stock, rating, reviewCount);
	}
    
    
}