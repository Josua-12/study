package test;

public class PersonTest {

	public static void main(String[] args) {
		// Person은 추상클래스라 직접 객체 생성 불가
		System.out.println("Person 추상클래스 구현 완료");
	}
}
