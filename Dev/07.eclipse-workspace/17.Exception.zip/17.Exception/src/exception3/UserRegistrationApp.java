package exception3;

public class UserRegistrationApp {

	public static void main(String[] args) {
		System.out.println("사용자 ID, 패스워드, 이메일 등록 검증");
		
		UserService userService = new UserService();
		
		// 2차원 배열 -- [사용자 ID, 패스워드, 이메일, 설명]
		String[][] registerCases = {
				{"dev001", "SecurePass123", "dev001@gmail.com", "정상 케이스"}
		};
		
		// 각 케이스를 순서대로 실행
		
	}
}
