
package com.choongang.studyreservesystem.repository;

import com.choongang.studyreservesystem.domain.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {
    @Query("SELECT r FROM Reservation r WHERE r.room.roomId = :roomId " +
            "AND r.status = 'CONFIRMED' " +
            "AND (r.startTime < :endTime AND r.endTime > :startTime)")
    List<Reservation> findConflictingReservations(
            @Param("roomId") Long roomId,
            @Param("startTime") LocalDateTime startTime,
            @Param("endTime") LocalDateTime endTime
    );

    Optional<Reservation> findByReservationIdAndUser_Username(Long reservationId, String username);

    boolean existsByRoom_RoomIdAndUser_UsernameAndStatus(Long roomId, String username, Reservation.ReservationStatus status);

    Optional<Reservation> findTopByRoom_RoomIdAndUser_UsernameAndStatusOrderByCreatedAtDesc(Long roomId, String username, Reservation.ReservationStatus status);

    List<Reservation> findByUser_UsernameOrderByCreatedAtDesc(String username);

    List<Reservation> findAllByEndTimeBeforeAndStatus(
            LocalDateTime endTimeBefore,
            Reservation.ReservationStatus status
    );


}
