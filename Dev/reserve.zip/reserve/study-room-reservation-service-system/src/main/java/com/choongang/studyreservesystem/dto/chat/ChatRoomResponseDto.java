package com.choongang.studyreservesystem.dto.chat;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.time.LocalDateTime;

@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatRoomResponseDto {

    private Long chatRoomId;
    private String roomName;
    private String masterName;
    private Long participantsCount;
    private LocalDateTime lastChatTime;
    private String lastMessage;
}
