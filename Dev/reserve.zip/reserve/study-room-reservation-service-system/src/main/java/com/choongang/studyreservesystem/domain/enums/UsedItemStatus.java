package com.choongang.studyreservesystem.domain.enums;

public enum UsedItemStatus {
    SELLING("판매 중"),
    RESERVED("거래 중"),
    SOLD("거래 완료"),
    HIDDEN("숨김 처리");    // 기타 이유료 제제(사기 등)

    private final String description;

    UsedItemStatus(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
