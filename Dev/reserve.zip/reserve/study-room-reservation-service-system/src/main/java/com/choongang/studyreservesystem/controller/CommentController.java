package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.domain.User;
//import com.choongang.studyreservesystem.dto.comment.CommentDeleteDto;
import com.choongang.studyreservesystem.dto.comment.CommentResponseDto;
import com.choongang.studyreservesystem.dto.comment.CommentSaveDto;
import com.choongang.studyreservesystem.dto.comment.CommentUpdateDto;
import com.choongang.studyreservesystem.security.CustomUserDetails;
import com.choongang.studyreservesystem.service.CommentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping("/comments")
public class CommentController {

    private final CommentService commentService;

    @PostMapping
    public ResponseEntity<CommentResponseDto> saveComment(
            @Valid @RequestBody CommentSaveDto saveDto,
            @AuthenticationPrincipal CustomUserDetails userDetails) {

        User currentUser = userDetails.getUser();
        CommentResponseDto commentResponseDto = commentService.saveComment(saveDto, currentUser);

        return ResponseEntity.status(HttpStatus.CREATED).body(commentResponseDto);
    }

    @PatchMapping("/{commentId}")
    public ResponseEntity<CommentResponseDto> updateComment(
            @PathVariable Long commentId,
            @Valid @RequestBody CommentUpdateDto updateDto,
            @AuthenticationPrincipal CustomUserDetails userDetails) {

        User currentUser = userDetails.getUser();
        CommentResponseDto updatedDto = commentService.updateComment(commentId, updateDto, currentUser);
        return ResponseEntity.status(HttpStatus.OK).body(updatedDto);
    }

    @DeleteMapping("/{commentId}")
    public ResponseEntity<Void> deleteComment(
            @PathVariable Long commentId,
            @AuthenticationPrincipal CustomUserDetails userDetails) {

        User currentUser = userDetails.getUser();
        commentService.deleteComment(commentId, currentUser);
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
    
   // 게시글의 댓글 목록 조회
    @GetMapping("/board/{boardId}")
     public ResponseEntity<List<CommentResponseDto>> getCommentsByBoard(
            @PathVariable Long boardId) {

        List<CommentResponseDto> comments = commentService.findByBoardPostId(boardId);
        return ResponseEntity.ok(comments);
    }
}
