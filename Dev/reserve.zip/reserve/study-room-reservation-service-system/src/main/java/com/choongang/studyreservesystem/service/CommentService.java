package com.choongang.studyreservesystem.service;

import com.choongang.studyreservesystem.dto.comment.CommentResponseDto;
import com.choongang.studyreservesystem.dto.comment.CommentSaveDto;
import com.choongang.studyreservesystem.dto.comment.CommentUpdateDto;
import com.choongang.studyreservesystem.domain.User;

import java.util.List;

public interface CommentService {

    CommentResponseDto saveComment(CommentSaveDto commentSaveDto, User user);

    CommentResponseDto updateComment(Long commentId, CommentUpdateDto commentUpdateDto, User user);

    List<CommentResponseDto> findByBoardPostId(Long boardId);

    void deleteComment(Long commentId, User currentUser);
}
