package com.choongang.studyreservesystem.repository.jpa;

import com.choongang.studyreservesystem.domain.chat.Chat;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatJpaRepository extends JpaRepository<Chat, Long> {
}
