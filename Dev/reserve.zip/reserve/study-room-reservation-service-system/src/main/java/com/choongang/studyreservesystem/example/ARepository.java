package com.choongang.studyreservesystem.example;

public interface ARepository {

    void save();
}
