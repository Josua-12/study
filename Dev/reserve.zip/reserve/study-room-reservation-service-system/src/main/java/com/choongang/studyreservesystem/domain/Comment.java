package com.choongang.studyreservesystem.domain;

import jakarta.persistence.*;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EntityListeners(AuditingEntityListener.class)
public class Comment extends BaseEntity {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 1000)
    private String comment;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "board_id",
            referencedColumnName = "postId",
            nullable = true
    )
    private Board board;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "used_item_post_id",
            nullable = true
    )
    private UsedItemPost usedItemPost;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(
            name = "user_id",
            referencedColumnName = "id",
            nullable = false
    )
    private User user;

    @Builder
    public Comment(String comment, Board board, UsedItemPost usedItemPost, User user) {
        this.comment = comment;
        this.board = board;
        this.usedItemPost= usedItemPost;
        this.user = user;
    }

    public void updateComment(String comment) {
        this.comment = comment;
    }

}
