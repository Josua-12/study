package com.choongang.studyreservesystem.repository.jpa;

import com.choongang.studyreservesystem.domain.chat.ChatRoom;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ChatRomeJpaRepository extends JpaRepository<ChatRoom, Long> {

    Optional<ChatRoom> findChatRoomByMasterIdAndRoomName(Long masterId, String roomName);

    // ChatRepository.java
    @Query("SELECT DISTINCT c FROM ChatRoom c LEFT JOIN c.participants p " +
            "WHERE c.masterId IN :userIds OR p IN :userIds")
    List<ChatRoom> findChatRoomsByOverlappingUsers(@Param("userIds") List<Long> userIds);

}
