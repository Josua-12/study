package com.choongang.studyreservesystem.config;

import com.choongang.studyreservesystem.domain.*;
import com.choongang.studyreservesystem.repository.BoardRepository;
import com.choongang.studyreservesystem.repository.ReservationRepository;
import com.choongang.studyreservesystem.repository.ReviewRepository;
import com.choongang.studyreservesystem.repository.UserRepository;
import com.choongang.studyreservesystem.repository.jpa.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class initDateConfig implements CommandLineRunner {

    private final UserRepository userRepository;
    private final BoardRepository boardRepository;
    private final PasswordEncoder passwordEncoder;
    private final ReviewRepository reviewRepository;
    private final RoomRepository roomRepository;
    private final ReservationRepository reservationRepository;


    @Override
    public void run(String... args) throws Exception {

        // User 데이터베이스가 비어있는 경우에만 초기 데이터 생성
        List<User> users = userRepository.findAll();
        if (users.size() == 0) {

            // 첫 번째 유저 생성 및 저장
            User user1 = User.builder()
                    .username("admin")
                    .password(passwordEncoder.encode("admin123"))
                    .name("관리자")
                    .email("admin@example.com")
                    .role("ROLE_ADMIN")
                    .build();
            userRepository.save(user1);

            // 두 번째 유저 생성 및 저장
            User user2 = User.builder()
                    .username("user1")
                    .password(passwordEncoder.encode("user123"))
                    .name("사용자1")
                    .email("user1@example.com")
                    .role("ROLE_USER")
                    .build();
            userRepository.save(user2);

            // 세 번째 유저 생성 및 저장
            User user3 = User.builder()
                    .username("user2")
                    .password(passwordEncoder.encode("user123"))
                    .name("사용자2")
                    .email("user2@example.com")
                    .role("ROLE_USER")
                    .build();
            userRepository.save(user3);
        }

        // Reservation 데이터베이스가 비어있는 경우에만 초기 데이터 생성
        List<Reservation> reservation = reservationRepository.findAll();
        Room room1 = roomRepository.findById(14L).orElseThrow();
        User user1 = userRepository.findById(2L).orElseThrow();
        User user2 = userRepository.findById(3L).orElseThrow();
        Reservation reservation1 = reservationRepository.findById(1L).orElse(null);

        // Review 데이터베이스가 비어있는 경우에만 초기 데이터 생성
        List<Review> reviews = reviewRepository.findAll();
        if (reviews.size() == 0) {
                    Review review1 = Review.builder()

                    .content("조용하고 깨끗해서 집중이 잘 돼요!")
                    .rating(5)
                    .likeCount(5L)
                    .reportCount(0L)
                    .room(room1)
                    .user(user2)
                    .reservation(reservation1)
                    .status(ReviewStatus.ACTIVE)
                    .visibility(Visibility.PUBLIC)
                    .build();

            Review review2 = Review.builder()
                    .content("에어컨이 조금 시끄럽지만 전체적으로 만족스러웠습니다.")
                    .rating(4)
                    .likeCount(2L)
                    .reportCount(0L)
                    .room(room1)
                    .user(user1)
                    .reservation(reservation1)
                    .status(ReviewStatus.ACTIVE)
                    .visibility(Visibility.PUBLIC)
                    .build();

            Review review3 = Review.builder()
                    .content("예약 시스템이 편리하고 스태프가 친절했어요.")
                    .rating(5)
                    .likeCount(10L)
                    .reportCount(0L)
                    .room(room1)
                    .user(user1)
                    .status(ReviewStatus.ACTIVE)
                    .visibility(Visibility.PUBLIC)
                    .build();

            Review review4 = Review.builder()
                    .content("조금 좁고 소음이 있었지만 가격이 저렴해서 괜찮았어요.")
                    .rating(4)
                    .likeCount(1L)
                    .reportCount(1L)
                    .room(room1)
                    .user(user1)
                    .status(ReviewStatus.HIDDEN)
                    .visibility(Visibility.HIDDEN_BY_REPORT)
                    .build();

            reviewRepository.saveAll(List.of(review1, review2, review3, review4));
            System.out.println("✅ Review 초기 데이터 4건이 생성되었습니다.");

        }

        // Board 데이터베이스가 비어있는 경우에만 초기 데이터 생성
        List<Board> boards = boardRepository.findAll();
        if (boards.size() == 0) {

            Board board1 = Board.builder()
                    .username("admin")
                    .title("스터디룸 예약 시스템을 소개합니다!")
                    .content("안녕하세요! 이 플랫폼은 스터디룸 예약부터 커뮤니티, 채팅까지 모두 한 곳에서 해결할 수 있는 종합 서비스입니다. 관심사가 맞는 친구들을 찾고, 함께 공부할 공간을 예약해보세요!")
                    .likeCount(0L)
                    .viewCount(120L)
                    .build();
            boardRepository.save(board1);

            Board board2 = Board.builder()
                    .username("user1")
                    .title("같이 자바 공부하실 분 찾아요!")
                    .content("자바 기초부터 스프링까지 함께 공부하실 분들을 찾습니다. 주 3회 정도 모여서 프로젝트도 함께 진행하면 좋을 것 같아요. 강남역 근처 스터디룸 선호합니다!")
                    .likeCount(0L)
                    .viewCount(89L)
                    .build();
            boardRepository.save(board2);

            Board board3 = Board.builder()
                    .username("user2")
                    .title("토익 스터디 모집 (4명)")
                    .content("다음 달 토익 시험을 준비하는 스터디원을 모집합니다. 현재 2명이고 2명 더 찾고 있어요. 매일 저녁 7시부터 3시간 정도 공부할 예정입니다. 홍대 근처 선호!")
                    .likeCount(0L)
                    .viewCount(156L)
                    .build();
            boardRepository.save(board3);

            Board board4 = Board.builder()
                    .username("admin")
                    .title("커뮤니티 이용 가이드")
                    .content("커뮤니티에서 관심사가 맞는 친구들을 찾아보세요. 게시글을 작성하고 댓글로 소통하며, 좋아요를 누르면 관심을 표현할 수 있습니다. 서로의 학습 목표를 공유하고 함께 성장해요!")
                    .likeCount(0L)
                    .viewCount(203L)
                    .build();
            boardRepository.save(board4);

            Board board5 = Board.builder()
                    .username("user1")
                    .title("코딩 테스트 대비 스터디")
                    .content("알고리즘 문제 풀이를 함께 할 스터디원을 찾습니다. 백준, 프로그래머스 문제를 풀고 코드 리뷰를 하며 실력을 키워요. 주말 오후 2시부터 4시간 정도 모일 예정입니다.")
                    .likeCount(0L)
                    .viewCount(134L)
                    .build();
            boardRepository.save(board5);

            Board board6 = Board.builder()
                    .username("user2")
                    .title("영어 회화 스터디 모집")
                    .content("영어 회화 실력을 향상시키고 싶은 분들을 모집합니다. 자유 주제로 영어로만 대화하는 시간을 가지려고 합니다. 중급 이상 수준이면 좋겠어요. 주 2회, 평일 저녁 선호합니다.")
                    .likeCount(0L)
                    .viewCount(178L)
                    .build();
            boardRepository.save(board6);

            Board board7 = Board.builder()
                    .username("admin")
                    .title("공무원 시험 스터디 모집")
                    .content("9급 공무원 시험을 준비하는 스터디입니다. 행정학, 행정법 위주로 공부하며 주 4회 모임을 가집니다. 신림역 근처 스터디룸에서 진행 예정이에요.")
                    .likeCount(0L)
                    .viewCount(267L)
                    .build();
            boardRepository.save(board7);

            Board board8 = Board.builder()
                    .username("user1")
                    .title("파이썬 데이터 분석 스터디")
                    .content("파이썬으로 데이터 분석을 배우고 싶은 분들을 모집합니다. Pandas, NumPy, Matplotlib 등을 다루며 실제 데이터로 프로젝트를 진행합니다. 초보자도 환영해요!")
                    .likeCount(0L)
                    .viewCount(198L)
                    .build();
            boardRepository.save(board8);

            Board board9 = Board.builder()
                    .username("user2")
                    .title("중국어 회화 스터디")
                    .content("HSK 준비와 함께 중국어 회화 실력을 키우는 스터디입니다. 원어민 친구와 함께 진행하며 주 2회 모임을 가집니다. 초급~중급 수준 환영합니다.")
                    .likeCount(0L)
                    .viewCount(145L)
                    .build();
            boardRepository.save(board9);

            Board board10 = Board.builder()
                    .username("admin")
                    .title("독서 토론 모임")
                    .content("한 달에 한 권씩 책을 읽고 토론하는 모임입니다. 인문학, 자기계발서 위주로 선정하며 다양한 관점을 나누는 시간을 가집니다. 편안한 분위기에서 진행돼요.")
                    .likeCount(0L)
                    .viewCount(167L)
                    .build();
            boardRepository.save(board10);

            Board board11 = Board.builder()
                    .username("user1")
                    .title("웹 개발 프로젝트 팀원 모집")
                    .content("React와 Node.js로 웹 서비스를 만들 팀원을 찾습니다. 포트폴리오 제작이 목표이며 3개월 정도 진행 예정입니다. 프론트엔드 2명, 백엔드 2명 모집합니다.")
                    .likeCount(0L)
                    .viewCount(112L)
                    .build();
            boardRepository.save(board11);

            Board board12 = Board.builder()
                    .username("user2")
                    .title("자격증 스터디 (정보처리기사)")
                    .content("정보처리기사 자격증 취득을 목표로 하는 스터디입니다. 필기와 실기를 함께 준비하며 기출문제 풀이와 개념 정리를 진행합니다. 주 3회 저녁 시간 모임입니다.")
                    .likeCount(0L)
                    .viewCount(189L)
                    .build();
            boardRepository.save(board12);

            Board board13 = Board.builder()
                    .username("admin")
                    .title("일본어 JLPT N2 대비반")
                    .content("JLPT N2 시험을 준비하는 스터디입니다. 문법, 독해, 청해를 골고루 학습하며 모의고사도 함께 풀어봅니다. 주 2회 평일 저녁에 모입니다.")
                    .likeCount(0L)
                    .viewCount(143L)
                    .build();
            boardRepository.save(board13);

            Board board14 = Board.builder()
                    .username("user1")
                    .title("수학 기초 다지기 스터디")
                    .content("고등 수학부터 다시 공부하고 싶은 분들을 위한 스터디입니다. 개념 이해와 문제 풀이를 병행하며 서로 가르쳐주는 방식으로 진행합니다. 수학 포기자도 환영!")
                    .likeCount(0L)
                    .viewCount(234L)
                    .build();
            boardRepository.save(board14);

            Board board15 = Board.builder()
                    .username("user2")
                    .title("영어 원서 읽기 모임")
                    .content("영어 원서를 함께 읽고 토론하는 모임입니다. 한 달에 한 권씩 읽으며 독해 실력과 어휘력을 향상시킵니다. 중급 이상 영어 실력이 필요해요.")
                    .likeCount(0L)
                    .viewCount(98L)
                    .build();
            boardRepository.save(board15);

            Board board16 = Board.builder()
                    .username("admin")
                    .title("취업 준비 스터디")
                    .content("이력서 작성, 자기소개서, 면접 준비를 함께 하는 스터디입니다. 서로 피드백을 주고받으며 취업 정보도 공유합니다. 같이 힘내서 취업 성공해요!")
                    .likeCount(0L)
                    .viewCount(201L)
                    .build();
            boardRepository.save(board16);

            Board board17 = Board.builder()
                    .username("user1")
                    .title("같은 관심사 친구 찾고 싶어요!")
                    .content("안녕하세요! 저는 경제학에 관심이 많은 대학생입니다. 스터디나 프로젝트를 함께할 친구를 찾고 있어요. 관심사가 비슷한 분 계시면 댓글 남겨주세요. 채팅방 만들어서 스터디룸 예약까지 같이 진행하면 좋겠네요!")
                    .likeCount(0L)
                    .viewCount(156L)
                    .build();
            boardRepository.save(board17);

            Board board18 = Board.builder()
                    .username("user2")
                    .title("경제 공부 모임")
                    .content("경제 뉴스를 읽고 토론하며 경제 상식을 쌓는 모임입니다. 주식, 부동산, 금융 등 다양한 주제를 다루며 투자 공부도 함께 합니다.")
                    .likeCount(0L)
                    .viewCount(187L)
                    .build();
            boardRepository.save(board18);

            Board board19 = Board.builder()
                    .username("admin")
                    .title("디자인 포트폴리오 스터디")
                    .content("UI/UX 디자인 포트폴리오를 만드는 스터디입니다. Figma, Adobe XD 등을 활용하며 서로의 작업물에 피드백을 주고받습니다. 디자이너 지망생 환영합니다.")
                    .likeCount(0L)
                    .viewCount(278L)
                    .build();
            boardRepository.save(board19);

            Board board20 = Board.builder()
                    .username("user1")
                    .title("영어 스피킹 집중반")
                    .content("영어 말하기에 집중하는 스터디입니다. 매 회 다른 주제로 영어로만 대화하며 발음 교정과 표현력 향상을 목표로 합니다. 고급 수준 환영합니다.")
                    .likeCount(0L)
                    .viewCount(165L)
                    .build();
            boardRepository.save(board20);

            Board board21 = Board.builder()
                    .username("user2")
                    .title("혼자 글쓰기 공부하기 지루해요 ㅠㅠ")
                    .content("혼자 공부하는 게 너무 지루하네요. 같이 공부할 친구를 찾고 있는데, 블로그 글쓰기 실력을 키우는 스터디가 있으면 좋겠어요. 매주 주제를 정해 글을 쓰고 서로 피드백을 나눌 생각이에요. 글쓰기에 관심 있는 분들 댓글 남겨주세요!")
                    .likeCount(0L)
                    .viewCount(312L)
                    .build();
            boardRepository.save(board21);
        } else {
            // 기존 데이터도 수정
            for (Board b : boards) {
                b.updateBoard(
                        (b.getTitle()== null ? "" : b.getTitle()),
                        (b.getContent() == null ? "" : b.getContent())
                );
                    boardRepository.save(b); // 변경내용 DB 반영

            }
        }









    }
}
