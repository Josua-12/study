package com.choongang.studyreservesystem.infrastructure.socket;

import com.choongang.studyreservesystem.dto.UserResponseDto;
import com.choongang.studyreservesystem.dto.chat.*;
import jakarta.validation.Valid;

import java.util.List;
import java.util.Queue;

public interface ChatService {
    Long createRoom(@Valid ChatRoomCreateDto chatRoomCreateDto);

    Long inviteUserToRoom(@Valid InviteChatRoomDto inviteChatRoomDto);

    void leaveRoom(Long chatRoomId, Long userId);

    Queue<ChatHistoryDto> getChatHistory(@Valid Long chatRoomId);

    List<ChatUserResponseDto> getRoomParticipants(@Valid Long chatRoomId);

    List<ChatRoomResponseDto> getUserChatRooms(@Valid Long userId);

    ChatRoomResponseDto getChatRoom(@Valid Long chatRoomId);
}
