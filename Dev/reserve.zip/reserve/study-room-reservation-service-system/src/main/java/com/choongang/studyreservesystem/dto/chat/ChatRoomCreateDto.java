package com.choongang.studyreservesystem.dto.chat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ChatRoomCreateDto {

    private Long masterId;
    private String masterName;
    private String roomName;
}
