package com.choongang.studyreservesystem.repository.jpa;

import com.choongang.studyreservesystem.domain.UsedItemPost;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsedItemPostRepository extends JpaRepository<UsedItemPost, Long> {


}
