package com.choongang.studyreservesystem.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
public class Board extends BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long postId;

	@Column(nullable = false)
	private String username;

	@Column(nullable = false)
	private String title;

	@Column(nullable = false, length = 1000)
	private String content;

	@Builder.Default
	private Long likeCount = 0L;

	@Builder.Default
	private Long viewCount = 0L;

	public void increaseViewCount() {
		this.viewCount++;
	}
	
	public void updateLikeCount(Long likeCount) {
		this.likeCount = likeCount;
	}

//    @Version
//    private Long version;   // 동시 수정 방지 (본인만 수정할 수 있으므로 비활성화 처리)

    // 작성자 null 허용(탈퇴 사용자)
    @ManyToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "author_id", nullable = true) // nullable 허용
    private User author;



    /** 제목+내용 수정 */
    public void updateBoard(String title, String content) {
        this.title = title;
        this.content = content;
    }

    /** 제목 수정 */
    public void changeTitle(String title) {
        this.title = title;
    }
    /** 내용 수정 */
    public void changeContent(String content) {
        this.content = content;
    }

    @OneToMany(
            mappedBy = "board",
            cascade = CascadeType.ALL
    )
    @Builder.Default
    private List<Comment> comments = new ArrayList<>(); //리뷰목록

}