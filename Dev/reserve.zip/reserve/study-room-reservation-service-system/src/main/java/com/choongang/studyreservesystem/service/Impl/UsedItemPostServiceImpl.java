package com.choongang.studyreservesystem.service.Impl;

import com.choongang.studyreservesystem.domain.UsedItemPost;
import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.domain.enums.UsedItemStatus;
import com.choongang.studyreservesystem.dto.useditempost.CreateUsedItemPostDto;
import com.choongang.studyreservesystem.dto.useditempost.UpdateUsedItemPostDto;
import com.choongang.studyreservesystem.dto.useditempost.UsedItemPostResponseDto;
import com.choongang.studyreservesystem.repository.UserRepository;
import com.choongang.studyreservesystem.repository.jpa.UsedItemPostRepository;
import com.choongang.studyreservesystem.service.UsedItemPostService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true) //======== 클래스 자체에 트랜잭션 readonly라서 생성 수정 삭제에는 트랜잭션 필수!
public class UsedItemPostServiceImpl implements UsedItemPostService {

    private final UsedItemPostRepository usedItemPostRepository;
    private final UserRepository userRepository;

    @Transactional
    @Override
    public UsedItemPostResponseDto createPost(CreateUsedItemPostDto createDto, Long authorId) {
        //작성자 조회
        User author = userRepository.findById(authorId)
                .orElseThrow(() -> new EntityNotFoundException("작성자를 찾을 수 없습니다."));

        // 엔티티로 변환
        UsedItemPost newItemPost = UsedItemPost.builder()
                .title(createDto.getTitle())
                .content(createDto.getContent())
                .price(createDto.getPrice())
                .location(createDto.getLocation())
                .author(author)
                .status(UsedItemStatus.SELLING)
                .build();
        //DB 저장
        UsedItemPost savedPost = usedItemPostRepository.save(newItemPost);

        //DTO로 반환
        return UsedItemPostResponseDto.from(savedPost);
    }

    @Transactional  // 조회수 증가 로직이 있으므로 필수 (더티 체킹)
    @Override
    public UsedItemPostResponseDto getPostById(Long itemId) {

        UsedItemPost usedItemPost = usedItemPostRepository.findById(itemId)
                .orElseThrow(() -> new EntityNotFoundException("중고 게시글을 찾을 수 없습니다."));
        // 조회수 증가 비즈니스 로직
        usedItemPost.increaseViewCount();

        //DTO로 변환 후 반환
        return UsedItemPostResponseDto.from(usedItemPost);
    }

    @Transactional
    @Override
    public void deletePost(Long itemId, Long authorId) {

        //해당 포스트 조회
        log.info("해당 게시글 존재여부 확인 및 권한 검증 시작! PostId : {}", itemId);
        UsedItemPost usedItemPost = usedItemPostRepository.findById(itemId)
                .orElseThrow(() -> new EntityNotFoundException("중고 게시글을 찾을 수 없습니다."));

        User requester = userRepository.findById(authorId)
                .orElseThrow(() -> new EntityNotFoundException("해당 유저를 찾을 수 없습니다."));

        boolean isAuthor = requester.getId().equals(usedItemPost.getAuthor().getId());
        boolean isAdmin = requester.getRole().equals("ADMIN");

        if (!isAuthor && !isAdmin) {
            throw new AccessDeniedException("게시글 삭제 권한이 없습니다.");
        }

        log.info("해당 게시글 존재여부 확인 및 권한 검증 확인 통과! PostId : {}", itemId);

        //엔티티에 붙어있는 @SQLDelete로 인해 소프트 삭제
        usedItemPostRepository.delete(usedItemPost);

        log.info("게시글 삭제 완료! 게시판 ID: {}", itemId);
    }

    @Transactional
    @Override
    public UsedItemPostResponseDto updatePost(Long itemId, UpdateUsedItemPostDto updateDto, Long authorId) {

        //해당 포스트 조회
        log.info("해당 게시글 존재여부 확인 및 권한 검증 시작 PostId : {}", itemId);
        UsedItemPost usedItemPost = usedItemPostRepository.findById(itemId)
                .orElseThrow(() -> new EntityNotFoundException("해당 게시글을 찾을 수 없습니다."));

        User requester = userRepository.findById(authorId)
                .orElseThrow(() -> new EntityNotFoundException("해당 유저를 찾을 수 없습니다."));

        boolean isAuthor = requester.getId().equals(usedItemPost.getAuthor().getId());
        //게시글 수정은 관리자가 할 필요가 없음
//        boolean isAdmin = requester.getRole().equals("ADMIN");

        if (!isAuthor) {
            throw new AccessDeniedException("게시글 수정 권한이 없습니다.");
        }

        log.info("해당 게시글 존재여부 확인 및 권한 검증 확인 통과 PostId : {}", itemId);

        usedItemPost.updateItem(
                updateDto.getTitle(),
                updateDto.getContent(),
                updateDto.getPrice(),
                updateDto.getLocation()
        );

        log.info("게시글 업데이트 완료! 게시판 ID: {}", itemId);

        return UsedItemPostResponseDto.from(usedItemPost);
    }

    /*업데이트 용 조회 메서드 검증 포함*/
    @Transactional(readOnly = true)
    @Override
    public UsedItemPostResponseDto getPostForEdit(Long itemId, Long authorId) {
        UsedItemPost itemPost = usedItemPostRepository.findById(itemId)
                .orElseThrow(() -> new EntityNotFoundException("게시글을 찾을 수 없습니다."));

        boolean isAuthor = itemPost.getAuthor().getId().equals(authorId);

        if (!isAuthor) {
            throw new AccessDeniedException("게시글을 수정할 권한이 없습니다.");
        }

        return UsedItemPostResponseDto.from(itemPost);
    }
}
