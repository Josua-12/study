package com.choongang.studyreservesystem.service;

import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.dto.review.ReviewResponseDTO;
import com.choongang.studyreservesystem.dto.review.ReviewSaveDto;
import com.choongang.studyreservesystem.dto.review.ReviewUpdateDto;

import java.util.List;

public interface ReviewService {

    ReviewSaveDto saveReview(ReviewSaveDto reviewSaveDto, User user);

    ReviewResponseDTO updateReview(Long reviewId, ReviewUpdateDto reviewUpdateDto, User user);

    void deleteReview(Long reviewId, User user);

    List<ReviewResponseDTO> getReviewByRoomId(Long roomId);

    boolean hasUserLiked(Long roomId, Long userId);

    void toggleLike(Long roomId, Long userId);

    boolean hasUserAlreadyReviewed(Long roomId, String username);

    void reportReview(Long reviewId, String reason, User reporter);

    ReviewResponseDTO getReviewById(Long reviewId);

}