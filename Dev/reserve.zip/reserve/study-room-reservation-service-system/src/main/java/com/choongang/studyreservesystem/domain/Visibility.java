package com.choongang.studyreservesystem.domain;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum Visibility {
    PUBLIC("공개"),   // 일반 사용자에게 노출
    HIDDEN_BY_REPORT("신고로 숨김"),   // 신고 자동/수동 처리로 숨김(관리자/작성자만 열람)
    ADMIN_ONLY("관리자 전용");         // 관리자 전용(삭제 등 사유로 완전 비노출에 준함)

    private final String label;

    @Override
    public String toString() {
        return label;
    }
}