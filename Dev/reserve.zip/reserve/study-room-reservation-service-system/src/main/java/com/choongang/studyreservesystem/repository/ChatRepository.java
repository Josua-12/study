package com.choongang.studyreservesystem.repository;

import com.choongang.studyreservesystem.domain.chat.Chat;
import com.choongang.studyreservesystem.domain.chat.ChatRoom;

import java.util.List;
import java.util.Optional;

public interface ChatRepository {

    Chat saveChat(Chat chat);

    ChatRoom saveChatRoom(ChatRoom chatRoom);

    Optional<ChatRoom> findChatRoomById(Long chatRoomId);

    Optional<ChatRoom> findChatRoomByMasterIdAndRoomName(Long masterId, String roomName);

    List<ChatRoom> findChatRoomsByUserId(Long userId);

    void removeChatRoom(ChatRoom chatRoom);
}
