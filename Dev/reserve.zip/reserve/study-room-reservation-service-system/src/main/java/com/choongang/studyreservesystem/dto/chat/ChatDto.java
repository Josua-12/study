package com.choongang.studyreservesystem.dto.chat;

import com.choongang.studyreservesystem.vo.ChatType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ChatDto {

    private Long chatRoomId;
    private Long senderId;
    private String senderName;
    private String message;
    private ChatType chatType;
}
