package com.choongang.studyreservesystem.service.Impl;

import com.choongang.studyreservesystem.dto.RoomSearchConditionDto;
import com.choongang.studyreservesystem.dto.RoomSummaryDto;
import com.choongang.studyreservesystem.dto.RoomSummaryProjection;
import com.choongang.studyreservesystem.repository.jpa.RoomRepository;
import com.choongang.studyreservesystem.service.jpa.RoomService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class RoomServiceImpl implements RoomService {
    private final RoomRepository roomRepository;

    @Override
    public List<RoomSummaryDto> findAllRooms(RoomSearchConditionDto cond) {
        Pageable pageable = PageRequest.of(cond.getPage(), cond.getSize());
        return roomRepository.search(cond, pageable).map(this::toDto).getContent();
    }

    @Override
    public RoomSummaryDto findRoom(Long roomId) {
        return roomRepository.findById(roomId)
                .map(r -> RoomSummaryDto.builder()
                        .roomId(r.getRoomId())
                        .roomName(r.getRoomName())
                        .shortAddress(r.getRoomAddress())
                        .content(r.getRoomContent())
                        .latitude(r.getLatitude())
                        .longitude(r.getLongitude())
                        .price(r.getRoomPrice())
                        .roomType(r.getRoomType())
                        .facilities(r.getFacilities())
                        .contactInfo(r.getContactInfo())
                        .reservePolicy(r.getReservePolicy())
                        .minCapacity(r.getMinCapacity())
                        .maxCapacity(r.getMaxCapacity())
                        .openTime(r.getOpenTime())
                        .closeTime(r.getCloseTime())
                        .isOpen24Hours(r.isOpen24Hours())
                        .internalPolicy(r.getInternalPolicy())
                        .thumbnailUrl(null)
                        .distanceMeters(null)
                        .highlight(false)
                        .build())
                .orElseThrow(() -> new IllegalArgumentException("Room Not Found: " + roomId));
    }

    @Override
    public List<RoomSummaryDto> findRoomByLatitudeAndLongitude(Double latitude, Double longitude, Integer radius) {
        Pageable pageable = PageRequest.of(0, 100);
        return roomRepository.findNear(latitude, longitude, radius, pageable).map(this::toDto).getContent();
    }

    private RoomSummaryDto toDto(RoomSummaryProjection p) {
        return RoomSummaryDto.builder()
                .roomId(p.getRoomId())
                .roomName(p.getRoomName())
                .shortAddress(p.getShortAddress())
                .content(p.getContent())
                .latitude(p.getLatitude())
                .longitude(p.getLongitude())
                .price(p.getPrice())
                .roomType(p.getRoomType())
                .thumbnailUrl(null)
                .distanceMeters(p.getDistanceMeters())
                .highlight(false)
                .build();
    }
}
