package com.choongang.studyreservesystem.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.Data;

@Data
public class RoomSearchConditionDto {
    private String keyword;
    private Double centerLat;
    private Double centerLng;

    @Min(100)
    @Max(50000)
    private Integer radius = 2000;
    @Min(0)
    private Integer page = 0;
    @Min(1)
    @Max(100)
    private Integer size = 20;

    private String sort = "distance,asc";
}
