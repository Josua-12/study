package com.choongang.studyreservesystem.repository;

import com.choongang.studyreservesystem.domain.Report;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
    
public interface ReportRepository extends JpaRepository<Report, Long> {

    // 어느 리뷰 id에 대한 신고 기록이 있는지 체크 하는 메서드 (관리자 기능 잇으면 오픈)
    //Optional<Report> findByTargetReview_IdAndReporterUser_Id(Long reviewId, Long userId);
}