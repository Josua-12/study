package com.choongang.studyreservesystem.service.Impl;

import com.choongang.studyreservesystem.domain.Reservation;
import com.choongang.studyreservesystem.domain.Room;
import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.dto.ReservationRequestDto;
import com.choongang.studyreservesystem.dto.ReservationResponseDto;
import com.choongang.studyreservesystem.repository.ReservationRepository;
import com.choongang.studyreservesystem.repository.UserRepository;
import com.choongang.studyreservesystem.repository.jpa.RoomRepository;
import com.choongang.studyreservesystem.service.ReservationService;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Transactional
public class ReservationServiceImpl implements ReservationService {
    private final ReservationRepository reservationRepository;
    private final RoomRepository roomRepository;
    private final UserRepository userRepository;

    @Override
    public ReservationResponseDto createReservation(ReservationRequestDto requestDto, String username) {
        if (requestDto.getEndTime().isBefore(requestDto.getStartTime()) || 
            requestDto.getEndTime().isEqual(requestDto.getStartTime())) {
            throw new IllegalArgumentException("종료 시간은 시작 시간보다 이후여야 합니다.");
        }

        Room room = roomRepository.findById(requestDto.getRoomId())
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 스터디룸입니다."));

        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다."));

        List<Reservation> conflicts = reservationRepository.findConflictingReservations(
                requestDto.getRoomId(),
                requestDto.getStartTime(),
                requestDto.getEndTime()
        );

        if (!conflicts.isEmpty()) {
            throw new IllegalArgumentException("해당 시간에 이미 예약이 존재합니다.");
        }

        Reservation reservation = Reservation.builder()
                .room(room)
                .user(user)
                .startTime(requestDto.getStartTime())
                .endTime(requestDto.getEndTime())
                .personCount(requestDto.getPersonCount())
                .phone(requestDto.getPhone())
                .status(Reservation.ReservationStatus.CONFIRMED)
                .build();

        Reservation saved = reservationRepository.save(reservation);
        return ReservationResponseDto.from(saved);
    }

    @Override
    public Optional<ReservationResponseDto> findActiveReservation(Long roomId, String username) {
        return reservationRepository.findTopByRoom_RoomIdAndUser_UsernameAndStatusOrderByCreatedAtDesc(
                roomId, username, Reservation.ReservationStatus.CONFIRMED)
                .map(ReservationResponseDto::from);
    }

    @Override
    public ReservationResponseDto cancelReservation(Long reservationId, String username) {
        Reservation reservation = reservationRepository
                .findById(reservationId)
                .orElseThrow(() -> new IllegalArgumentException("예약을 찾을 수 없습니다."));

        if (!reservation.getUser().getUsername().equals(username)) {
            throw new IllegalArgumentException("예약 취소 권한이 없습니다.");
        }

        if (!reservation.isConfirmed()) {
            throw new IllegalArgumentException("이미 취소된 예약입니다.");
        }

        if (reservation.getStartTime().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("이미 사용 시작된 예약은 취소할 수 없습니다.");
        }
        reservation.cancel();
        return ReservationResponseDto.from(reservationRepository.save(reservation));
    }

    @Override
    public ReservationResponseDto getReservation(Long id, String username) {
        Reservation r= reservationRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("예약을 찾을 수 없습니다."));
        if (!r.getUser().getUsername().equals(username)) {
            throw new IllegalArgumentException("해당 예약을 확인할 권한이 없습니다.");
        }
        return ReservationResponseDto.from(r);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReservationResponseDto> findMyReservations(String username) {
        return reservationRepository.findByUser_UsernameOrderByCreatedAtDesc(username).stream()
                .map(ReservationResponseDto::from)
                .toList();
    }

    @Override
    public boolean hasCompletedReservations(Long roomId, String username) {
        return reservationRepository.existsByRoom_RoomIdAndUser_UsernameAndStatus(
                roomId, username, Reservation.ReservationStatus.COMPLETED);
    }

    @Transactional
    @Override
    public void updateReservationStatusToCompleted(Long reservationId) {

        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new EntityNotFoundException("예약 ID를 찾을 수 없습니다: " + reservationId));

        reservation.setStatus(Reservation.ReservationStatus.COMPLETED);

        reservationRepository.save(reservation);
    }
}
