package com.choongang.studyreservesystem.dto;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReservationRequestDto {
    @NotNull(message = "스터디룸을 선택해주세요")
    private Long roomId;

    @NotNull(message = "시작 시간을 입력해주세요")
    @Future(message = "시작 시간은 현재 시간 이후여야 합니다")
    private LocalDateTime startTime;

    @NotNull(message = "종료 시간을 입력해주세요")
    @Future(message = "종료 시간은 현재 시간 이후여야 합니다")
    private LocalDateTime endTime;

    @NotNull(message = "인원수를 선택해주세요")
    private Integer personCount;

    // 전화번호 검증 추가 - 형식 : 010-1234-5678
    @NotBlank(message = "전화번호를 입력해주세요 (형식 : 010-1234-5678)")
    @Pattern(regexp = "^\\d{3}-\\d{4}-\\d{4}$",
            message = "전화번호 형식이 올바르지 않습니다 (예: 010-1234-5678)")
    private String phone;
}
