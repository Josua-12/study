package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.dto.report.ReportRequestDto;
import com.choongang.studyreservesystem.service.ReviewService;
import com.choongang.studyreservesystem.security.CustomUserDetails;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/reviews")
public class ReviewApiController {

    private final ReviewService reviewService;

    @PostMapping("/{reviewId}/like")
    public ResponseEntity<String> toggleReviewLike(
            @PathVariable Long reviewId,
            @AuthenticationPrincipal CustomUserDetails userDetails) {

        if (userDetails == null) {
            return ResponseEntity.status(401).body("로그인이 필요합니다.");
        }

        Long userId = userDetails.getUser().getId();

        try {

            reviewService.toggleLike(reviewId, userId);


            boolean isLiked = reviewService.hasUserLiked(reviewId, userId);

            return ResponseEntity.ok(isLiked ? "좋아요 등록 성공" : "좋아요 취소 성공");
        } catch (IllegalArgumentException e) {

            return ResponseEntity.badRequest().body("처리 오류: " + e.getMessage());
        } catch (Exception e) {

            return ResponseEntity.internalServerError().body("서버 내부 오류가 발생했습니다.");
        }
    }
    @PostMapping("/report")
    public ResponseEntity<String> reportReview(
            @Valid @RequestBody ReportRequestDto requestDto,
            @AuthenticationPrincipal CustomUserDetails userDetails){

        try{

            User reporter = userDetails.getUser();
            reviewService.reportReview(
                    requestDto.getReviewId(),
                    requestDto.getReason(),
                    reporter
            );
            return ResponseEntity.ok("신고가 접수되었습니다. 관리자가 검토 후 처리할 예정입니다.");

        }catch(IllegalArgumentException e){
            return ResponseEntity.badRequest().body(e.getMessage());
        }catch(Exception e){
            return ResponseEntity.internalServerError().body("신고 처리 중 시스템 오류가 발생했습니다.");
        }
    }
}