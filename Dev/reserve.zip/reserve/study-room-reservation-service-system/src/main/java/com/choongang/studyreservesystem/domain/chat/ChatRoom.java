package com.choongang.studyreservesystem.domain.chat;


import com.choongang.studyreservesystem.dto.chat.ChatRoomCreateDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.*;

@Builder
@Entity
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ChatRoom {

    @Id
    @Column(name = "CHAT_ROOM_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long chatRoomId;

    @Column(name = "USER_ID", nullable = false)
    private Long masterId;

    @Column(name = "MASTER_NAME", nullable = false)
    private String masterName;

    @Column(name = "ROOM_NAME",nullable = false)
    private String roomName;

    @OneToMany(mappedBy = "chatRoom", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Chat> chats = new ArrayList<>();

    @Builder.Default
    @ElementCollection
    private List<Long> participants = new ArrayList<>();

    @Column(name = "CREATE_TIME", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @Builder.Default
    private LocalDateTime createTime = LocalDateTime.now();

    public static ChatRoom createChatRoom(ChatRoomCreateDto chatRoomCreateDto) {
        return ChatRoom.builder()
                .masterId(chatRoomCreateDto.getMasterId())
                .masterName(chatRoomCreateDto.getMasterName())
                .roomName(chatRoomCreateDto.getRoomName())
                .build();
    }

    public void addParticipant(Long userId) {
        if (!participants.contains(userId)) {
            participants.add(userId);
        }
    }

    public void removeParticipant(Long userId) {
        participants.remove(userId);
    }
}