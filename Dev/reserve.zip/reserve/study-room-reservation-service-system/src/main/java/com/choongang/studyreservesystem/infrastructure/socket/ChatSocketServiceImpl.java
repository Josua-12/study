package com.choongang.studyreservesystem.infrastructure.socket;

import com.choongang.studyreservesystem.domain.chat.Chat;
import com.choongang.studyreservesystem.domain.chat.ChatRoom;
import com.choongang.studyreservesystem.dto.chat.ChatDto;
import com.choongang.studyreservesystem.exception.ChatRoomAccessDeniedException;
import com.choongang.studyreservesystem.exception.ChatRoomNotFoundException;
import com.choongang.studyreservesystem.repository.ChatRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Component
public class ChatSocketServiceImpl implements ChatSocketService {

    private final ChatRepository chatRepository;

    @Autowired
    public ChatSocketServiceImpl(ChatRepository chatRepository) {
        this.chatRepository = chatRepository;
    }

    @Override
    @Transactional
    public void sendMessage(ChatDto chatDto) {
        ChatRoom chatRoom = chatRepository.findChatRoomById(chatDto.getChatRoomId())
                .orElseThrow(() -> new ChatRoomNotFoundException("Chat room not found with id: "
                        + chatDto.getChatRoomId()));
        if (!chatRoom.getParticipants().contains(chatDto.getSenderId())) {
            log.error("User id: {} is not a participant of chat room id: {}",
                    chatDto.getSenderId(), chatRoom.getChatRoomId());
            throw new ChatRoomAccessDeniedException("Chat room access denied by user id: " +
                    chatDto.getSenderId());
        }
        log.info("Sending message to chat room: {}", chatRoom.getChatRoomId());
        Chat chat = Chat.createChat(chatDto, chatRoom);
        chatRepository.saveChat(chat);
    }


    @Override
    @Transactional(readOnly = true)
    public void joinRoom(Long chatRoomId, Long userId) {
        log.info("Joining room: {} userId : {}", chatRoomId, userId);
        ChatRoom chatRoom = chatRepository.findChatRoomById(chatRoomId)
                .orElseThrow(() ->
                        new ChatRoomNotFoundException("Chat room not found with id: " + chatRoomId));
        chatRoom.getParticipants().stream().filter(id-> !id.equals(userId))
                .findFirst()
                .orElseThrow(() -> new ChatRoomAccessDeniedException("Chat room access " +
                        "denied by user id: " + userId));
    }
}
