package com.choongang.studyreservesystem.vo;

public enum ChatType {
    ENTER, TALK, LEAVE
}
