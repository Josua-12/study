package com.choongang.studyreservesystem.controller;

import com.choongang.studyreservesystem.dto.UserPasswordChangeDto;
import com.choongang.studyreservesystem.dto.UserRegisterDto;
import com.choongang.studyreservesystem.exception.UserDuplicationException;
import com.choongang.studyreservesystem.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.RequiredArgsConstructor;



@Controller
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/register")
    public String userRegister(Model model) {
        UserRegisterDto dto = new UserRegisterDto();
        model.addAttribute("user", dto);
        return "user/register";
    }

    @PostMapping("/register")
    public String postMethodName(UserRegisterDto dto, Model model) throws UserDuplicationException {
        userService.register(dto);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String userLogin() {
        return "auth/login";
    }
    @GetMapping("/help")
    public String findIdAndPassword(Model model) {
        UserPasswordChangeDto dto = new UserPasswordChangeDto();
        model.addAttribute("user", dto);
        return "help";
    }

    @PostMapping("/reset-password")
    public String resetPassword(UserPasswordChangeDto dto, Model model) {
        if (userService.matchUsernameAndEmail(dto)) {
            model.addAttribute("user", dto);
            return "user/password-change";
        }
        return "redirect:/help";
    }

    @PostMapping("/change-password")
    public String methodName(UserPasswordChangeDto dto) {
        userService.passwordChange(dto);
        return "redirect:/login";
    }
}
