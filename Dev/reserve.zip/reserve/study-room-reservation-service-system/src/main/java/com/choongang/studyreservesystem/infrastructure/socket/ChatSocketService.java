package com.choongang.studyreservesystem.infrastructure.socket;

import com.choongang.studyreservesystem.dto.chat.ChatDto;

public interface ChatSocketService {

    void sendMessage(ChatDto chatDto);

    void joinRoom(Long chatRoomId, Long userId);

}
