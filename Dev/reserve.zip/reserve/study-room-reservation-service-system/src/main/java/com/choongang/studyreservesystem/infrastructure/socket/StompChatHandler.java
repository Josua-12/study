package com.choongang.studyreservesystem.infrastructure.socket;

import com.choongang.studyreservesystem.dto.chat.ChatDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Slf4j
@Controller
public class StompChatHandler {

    private final ChatSocketService chatSocketService;

    private final SimpMessagingTemplate messagingTemplate;

    public StompChatHandler(ChatSocketService chatSocketService,
                            SimpMessagingTemplate messagingTemplate) {
        this.chatSocketService = chatSocketService;
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/chat/message")
    public void handleStompMessage(ChatDto chatDto) {
        String destination = "/topic/chat/room/" + chatDto.getChatRoomId();
        log.info("destination : {}, chatDto : {}",destination,chatDto.toString());
        log.info("chatType : {}",chatDto.getChatType());
        switch (chatDto.getChatType()) {
            case TALK:
                chatSocketService.sendMessage(chatDto);
                messagingTemplate.convertAndSend(destination, chatDto);
                log.info("TALK message broadcasted to {}: {}", destination, chatDto.getMessage());
                break;

            case ENTER:
                chatSocketService.joinRoom(chatDto.getChatRoomId(), chatDto.getSenderId());
                chatDto.setMessage(chatDto.getSenderName() + "님이 입장했습니다.");
                messagingTemplate.convertAndSend(destination, chatDto);
                log.info("User {} ENTERED room {}", chatDto.getSenderId(), chatDto.getChatRoomId());
                break;

            case LEAVE:
                chatDto.setMessage(chatDto.getSenderName() + "님이 퇴장했습니다.");
                messagingTemplate.convertAndSend(destination, chatDto);
                log.info("User {} LEFT room {}", chatDto.getSenderId(), chatDto.getChatRoomId());
                break;

            default:
                log.warn("Unknown chat type received: {}", chatDto.getChatType());
                break;
        }
    }
}