package com.choongang.studyreservesystem.dto.comment;

import com.choongang.studyreservesystem.domain.Comment;
import lombok.Getter;


import java.time.LocalDateTime;

@Getter
public class CommentResponseDto {
    private final Long id;
    private final String comment;
    private final String userName;
    private final LocalDateTime createdAt;
    private final LocalDateTime updatedAt;

    private CommentResponseDto(Long id, String comment, String userName,
                              LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.id = id;
        this.comment = comment;
        this.userName = userName;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }


    public static CommentResponseDto from(Comment comment) {
        return new CommentResponseDto(
                comment.getId(),
                comment.getComment(),
                comment.getUser().getUsername(),
                comment.getCreatedAt(),
                comment.getUpdatedAt()
        );
    }
}
