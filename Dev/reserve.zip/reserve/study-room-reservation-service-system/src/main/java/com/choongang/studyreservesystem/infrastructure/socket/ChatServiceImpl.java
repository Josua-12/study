package com.choongang.studyreservesystem.infrastructure.socket;

import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.domain.chat.ChatRoom;
import com.choongang.studyreservesystem.dto.UserResponseDto;
import com.choongang.studyreservesystem.dto.chat.*;
import com.choongang.studyreservesystem.exception.ChatRoomNotFoundException;
import com.choongang.studyreservesystem.exception.UserNotFoundException;
import com.choongang.studyreservesystem.mapper.ChatDataMapper;
import com.choongang.studyreservesystem.repository.ChatRepository;
import com.choongang.studyreservesystem.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ChatServiceImpl implements ChatService {


    private final ChatDataMapper chatDataMapper;
    private final ChatRepository chatRepository;
    private final UserRepository userRepository;
    @Autowired
    public ChatServiceImpl(ChatDataMapper chatDataMapper,
                                 ChatRepository chatRepository,
                                 UserRepository userRepository) {
        this.chatDataMapper = chatDataMapper;
        this.chatRepository = chatRepository;
        this.userRepository = userRepository;
    }
    @Override
    @Transactional
    public Long createRoom(ChatRoomCreateDto chatRoomCreateDto) {
        ChatRoom chatRoom = ChatRoom.createChatRoom(chatRoomCreateDto);
        chatRoom.addParticipant(chatRoomCreateDto.getMasterId());
        ChatRoom saved = chatRepository.saveChatRoom(chatRoom);
        log.info("Created room: {}, masterId : {}", saved.getChatRoomId(), saved.getMasterId());
        return saved.getChatRoomId();
    }
    @Override
    @Transactional
    public Long inviteUserToRoom(InviteChatRoomDto inviteChatRoomDto) {
        ChatRoom chatRoom = chatRepository.findChatRoomById(inviteChatRoomDto.getRoomId())
                .orElseThrow(() -> new ChatRoomNotFoundException("Chat room not found with id: " +
                        inviteChatRoomDto.getMasterId()));
        if (chatRoom.getMasterId().equals(inviteChatRoomDto.getInviteeId())) {
            throw new IllegalArgumentException("Master cannot be invited to their own chat room.");
        }
        userRepository.findById(inviteChatRoomDto.getInviteeId())
                .orElseThrow(() -> new UserNotFoundException("User not found with id: " +
                        inviteChatRoomDto.getInviteeId()));
        chatRoom.addParticipant(inviteChatRoomDto.getInviteeId());
        return chatRoom.getChatRoomId();
    }

    @Override
    @Transactional
    public void leaveRoom(Long chatRoomId, Long userId) {
        ChatRoom chatRoom = chatRepository.findChatRoomById(chatRoomId).orElseThrow(()
                -> new ChatRoomNotFoundException("Chat room not found with id: " + chatRoomId));
        if (!chatRoom.getMasterId().equals(userId)) {
            chatRoom.removeParticipant(userId);
            log.info("Leaving room: {} userId : {}",
                    chatRoom.getChatRoomId(), userId);
            return;
        }
        chatRepository.removeChatRoom(chatRoom);
    }

    @Override
    @Transactional(readOnly = true)
    public Queue<ChatHistoryDto> getChatHistory(Long chatRoomId) {
        ChatRoom chatRoom = chatRepository
                .findChatRoomById(chatRoomId).orElseThrow(() -> new ChatRoomNotFoundException("Chat room not found with id: " + chatRoomId));
        log.info("Getting chat history for room: {}", chatRoom.getChatRoomId());
        return chatRoom.getChats().stream().map(chat -> chatDataMapper
                .chatToChatHistoryDto(chatRoomId, chat)).collect(Collectors.toCollection(() ->
                new PriorityQueue<>(Comparator.comparing(ChatHistoryDto::getCreateTime))));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChatUserResponseDto> getRoomParticipants(Long chatRoomId) {
        List<Long> participants = chatRepository.findChatRoomById(chatRoomId)
                .orElseThrow(() -> new ChatRoomNotFoundException("Chat room not found with id: " + chatRoomId))
                .getParticipants();
        return participants.stream()
                .map(userId -> userRepository.findById(userId)
                        .orElseThrow(() -> new UserNotFoundException("User not found with id: " + userId)))
                .map(chatDataMapper::userToChatUserResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<ChatRoomResponseDto> getUserChatRooms(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() ->
                new UserNotFoundException("User not found with id: " + userId));
        List<ChatRoom> roomList = chatRepository.findChatRoomsByUserId(userId);
        return roomList.stream()
                .map(chatRoom -> chatDataMapper.chatRoomToChatRoomResponseDto(chatRoom, user))
                .collect(Collectors.toList());
    }

    @Override
    public ChatRoomResponseDto getChatRoom(Long chatRoomId) {
        ChatRoom chatRoom = chatRepository.findChatRoomById(chatRoomId).orElseThrow(() -> new
                ChatRoomNotFoundException("Chat room not found with id: " + chatRoomId));
        return chatDataMapper.toChatRoomResponseDto(chatRoom);
    }
}
