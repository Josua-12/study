package com.choongang.studyreservesystem.service;

import com.choongang.studyreservesystem.dto.useditempost.CreateUsedItemPostDto;
import com.choongang.studyreservesystem.dto.useditempost.UpdateUsedItemPostDto;
import com.choongang.studyreservesystem.dto.useditempost.UsedItemPostResponseDto;

public interface UsedItemPostService {

    UsedItemPostResponseDto createPost(CreateUsedItemPostDto createDto, Long authorId);

    UsedItemPostResponseDto getPostById(Long itemId);

    void deletePost(Long itemId, Long authorId);

    UsedItemPostResponseDto updatePost(Long itemId, UpdateUsedItemPostDto updateDto, Long authorId);

    UsedItemPostResponseDto getPostForEdit(Long itemId, Long authorId);

}
