package com.choongang.studyreservesystem.service;

import com.choongang.studyreservesystem.domain.User;
import com.choongang.studyreservesystem.dto.ReservationRequestDto;
import com.choongang.studyreservesystem.dto.ReservationResponseDto;
import com.choongang.studyreservesystem.dto.review.ReviewSaveDto;

import java.util.List;
import java.util.Optional;

public interface ReservationService {
    ReservationResponseDto createReservation(ReservationRequestDto requestDto, String username);
    Optional<ReservationResponseDto> findActiveReservation(Long roomId, String username);
    ReservationResponseDto cancelReservation(Long reservationId, String username);
    ReservationResponseDto getReservation(Long id, String username);
    List<ReservationResponseDto> findMyReservations(String username);
    boolean hasCompletedReservations(Long roomId, String username);
    void updateReservationStatusToCompleted(Long reservationId);
}
