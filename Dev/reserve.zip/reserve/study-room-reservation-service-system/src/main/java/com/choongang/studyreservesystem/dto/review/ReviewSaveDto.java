package com.choongang.studyreservesystem.dto.review;

import com.choongang.studyreservesystem.domain.Review;
import jakarta.validation.constraints.*;
import lombok.*;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Setter
public class ReviewSaveDto {
    @NotNull(message ="해당 스터디룸이 존재하지 않습니다.")
    private long roomId;

    @NotBlank(message = "리뷰 내용은 필수 입니다.")
    @Size(max = 1000,message = "리뷰 내용은 1000자를 초과할수 없습니다.")
    private String content;

    @NotNull(message = "평점을 선택해주세요.")
    @Min(value = 1, message = "평점은 1점 이상이어야 합니다.")
    @Max(value = 5, message = "평점은 5점을 초과할 수 없습니다.")
    private Integer rating;

    public static ReviewSaveDto from(Review review) {
        return ReviewSaveDto.builder()
                .roomId(review.getRoom().getRoomId())
                .content(review.getContent())
                .rating(review.getRating())
                .build();
    }

}
