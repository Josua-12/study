package com.choongang.studyreservesystem.example;

public class MyBatisMapper {
}
