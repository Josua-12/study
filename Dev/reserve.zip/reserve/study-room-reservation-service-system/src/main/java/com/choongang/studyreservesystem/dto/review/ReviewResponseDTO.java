package com.choongang.studyreservesystem.dto.review;

import com.choongang.studyreservesystem.domain.Reservation;
import com.choongang.studyreservesystem.domain.Review;
import com.choongang.studyreservesystem.domain.ReviewStatus;
import lombok.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Builder
public class ReviewResponseDTO {
    private Long reviewId;
    private Long roomId;
    private String roomName;
    private String content;
    private Integer rating;
    private Long likeCount;
    private Long reportCount;          // 신고 횟수
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String reviewer;
    private Long userId;    // 타임리프에서 작성자 권한확인을 위한 필드 추가
    private ReviewStatus status;      // ACTIVE, HIDDEN, DELETED 등 상태 표시
    private boolean editable;         // 타임리프에서 수정 버튼 활성화 여부 확인을 위한 필드 추가
    private boolean deletable;        // 타임리프에서 삭제 버튼 활성화 여부 확인을 위한 필드 추가


    public static ReviewResponseDTO from(Review review, Long currentUserId, boolean isAdmin) {
        return ReviewResponseDTO.builder()
                .reviewId(review.getId())
                .roomId(review.getRoom().getRoomId())
                .roomName(review.getRoom().getRoomName())
                .content(review.getContent())
                .rating(review.getRating())
                .likeCount(review.getLikeCount())
                .reportCount(review.getReportCount())
                .createdAt(review.getCreatedAt())
                .updatedAt(review.getUpdatedAt())
                .reviewer(review.getUser().getName())
                .userId(review.getUser().getId())   // 타임리프에서 작성자 권한확인을 위한 필드 추가
                .status(review.getStatus())
                .editable(isAdmin || review.getUser().getId().equals(currentUserId))  // 관리자 or 작성자에게 수정버튼 노출
                .deletable(isAdmin || review.getUser().getId().equals(currentUserId)) // 관리자 or 작성자에게 삭제버튼 노출
                .build();
    }

    public static ReviewResponseDTO from(Review review) {
        return from(review, null, false);
    }


}
