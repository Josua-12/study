class RoomMapService {
    constructor() {
        this.map = null;
        this.clusterer = null;
        this.geocoder = null;
        this.form = document.getElementById('searchForm');

        this.initKakaoMap();
        this.bindEvents();
    }

    initKakaoMap() {
        if (!window.APP_CONFIG?.kakaoApiKey) {
            console.error('카카오맵 API 키가 설정되지 않았습니다.');
            return;
        }

        const script = document.createElement('script');
        script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${window.APP_CONFIG.kakaoApiKey}&libraries=services,clusterer&autoload=false`;
        script.onload = () => {
            kakao.maps.load(() => this.createMap());
        };
        document.head.appendChild(script);
    }

    createMap() {
        const center = this.getInitialCenter();

        this.map = new kakao.maps.Map(document.getElementById('map'), {
            center: new kakao.maps.LatLng(center.lat, center.lng),
            level: 5
        });

        this.clusterer = new kakao.maps.MarkerClusterer({
            map: this.map,
            averageCenter: true,
            minLevel: 7
        });

        this.geocoder = new kakao.maps.services.Geocoder();

        // 초기 데이터 표시
        if (window.APP_CONFIG.initialResults?.length > 0) {
            this.displayResults(window.APP_CONFIG.initialResults);
        }
    }

    getInitialCenter() {
        const lat = parseFloat(this.form.centerLat.value) || 37.5665;
        const lng = parseFloat(this.form.centerLng.value) || 126.9780;
        return { lat, lng };
    }

    bindEvents() {
        this.form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSearch();
        });
    }

    async handleSearch() {
        const keyword = this.form.keyword.value?.trim();

        if(keyword) {
            await this.searchByAddress(keyword);
        }

        await this.searchRooms();
    }

    searchByAddress(keyword) {
        return new Promise((resolve) => {
            this.geocoder.addressSearch(keyword, (result, status) => {
                if (status === kakao.maps.services.Status.OK && result.length > 0) {
                    const coords = new kakao.maps.LatLng(result[0].y, result[0].x);
                    this.map.setCenter(coords);
                    this.form.centerLat.value = result[0].y;
                    this.form.centerLng.value = result[0].x;
                }
                resolve();
            });
        });
    }

    async searchRooms() {
        try {
            const formData = new FormData(this.form);
            const params = new URLSearchParams(formData);

            const response = await fetch(`/room/list/data?${params}`);
            if (!response.ok) throw new Error('검색 요청 실패');

            const rooms = await response.json();
            this.displayResults(rooms);
        } catch (error) {
            console.error('검색 중 오류 발생 : ', error);
            this.showErrorMessage('검색 중 오류가 발생했습니다.');
        }
    }

    displayResults(rooms) {
        this.updateRoomList(rooms);
        this.updateMapMarkers(rooms);
    }

    updateRoomList(rooms) {
        const resultList = document.getElementById(`resultList`);

        if (rooms.length === 0) {
            resultList.innerHTML = '<div class="text-center text-muted p-3">검색 결과가 없습니다.</div>';
            return;
        }

        resultList.innerHTML = rooms.map(room => `
            <a href="/room/${room.roomId}" class="list-group-item list-group-item-action">
                <div class="d-flex w-100 justify-content-between">
                    <h6 class="mb-1">${room.roomName}</h6>
                    <small>${room.price ? room.price.toLocaleString() + '원' : '가격 문의'}</small>
                </div>
                <p class="mb-1">${room.shortAddress}</p>
                <small class="test-muted">${room.roomType || ''} ${room.distanceMeters ? '* ' + room.distanceMeters + 'm' : ''}</small>
            </a>
        `).join('');
    }

    updateMapMarkers(rooms) {
        this.clusterer.clear();

        if(rooms.length === 0) return;

        const markers = rooms.map(room => {
            const marker = new kakao.maps.Marker({
                position: new kakao.maps.LatLng(room.latitude, room.longitude)
            });

            const infoWindow = new kakao.maps.InfoWindow({
                content: `
                    <div style="padding: 8px; min-width: 150px;">
                        <div style="font-weight: bold; margin-bottom: 4px;">${room.roomName}</div>
                        <div style="font-size: 12px; color: #666;">${room.shortAddress}</div>
                        ${room.price ? `<div style="color: #007bff; font-weight: bold; margin-top: 4px;">${room.price.toLocaleString()}원</div>` : ''}
                    </div>
                `
            });

            kakao.maps.event.addListener(marker, 'click', () => {
                infoWindow.open(this.map, marker);
            });

            return marker;
        });

        this.clusterer.addMarkers(markers);
    }

    showErrorMessage(message) {
        const resultList = document.getElementById('resultList');
        resultList.innerHTML = `<div class="alert alert-danger" role="alert">${message}</div>`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new RoomMapService();
});
